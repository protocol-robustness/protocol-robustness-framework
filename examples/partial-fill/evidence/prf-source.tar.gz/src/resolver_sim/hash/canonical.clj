(ns resolver-sim.hash.canonical
  "Canonical hash implementation per CANONICAL_HASH_SPEC_V1
   and CANONICAL_HASH_SPEC_V1_BINARY_ENCODING_ABI.

   This is the single authoritative hashing implementation for all
   evidence, world-state, manifest, and bundle hashing. All new code
   MUST use this namespace. The old resolver-sim.benchmark.hashing
   is deprecated.

   API:
     (validate-canonical-value! value)     — throws on unsupported types
     (canonical-bytes value)               — byte-array of typed encoding
     (hash-bytes bytes)                    — raw SHA-256 digest (32 bytes)
     (domain-hash domain-tag value)        — SHA-256(domain_tag || canonical_bytes), returns hex"
  (:refer-clojure :exclude [read-string])
  (:import [java.security MessageDigest]
           [java.io ByteArrayOutputStream]
           [java.math BigInteger BigDecimal])
  (:require [prf.canonical.codec :as canonical-codec]
            [clojure.string :as str]
            [clojure.edn :as edn]
            [resolver-sim.hash.algorithm :as hash-algorithm]
            [resolver-sim.hash.reference :as hash-ref]))

(declare domain-hash out-of-domain! strip-self-hash-fields)

;; ──────────────────────────────────────────────────────────────────────────────
;; Type Tags (per Binary Encoding ABI)
;; ──────────────────────────────────────────────────────────────────────────────

(def ^:const tag-null (byte 0x00))
(def ^:const tag-bool-false (byte 0x01))
(def ^:const tag-bool-true (byte 0x02))
(def ^:const tag-int (byte 0x10))
(def ^:const tag-ratio (byte 0x11))
(def ^:const tag-string (byte 0x20))
(def ^:const tag-keyword (byte 0x22))
(def ^:const tag-array (byte 0x30))
(def ^:const tag-map (byte 0x31))

;; ──────────────────────────────────────────────────────────────────────────────
;; Domain Tags (per Canonical Hash Spec V1)
;; ──────────────────────────────────────────────────────────────────────────────

(def domain-tags
  "Map of keyword domain identifiers to their ASCII domain tag strings.
   The domain tag is prepended to canonical bytes before hashing
   to prevent cross-domain hash collisions.

   NOTE: Maintained for backward compatibility with callers that
   pass keywords to domain-hash. Intent contracts now use strings
   directly via :intent/domain-tag."
  {:replay-frame "PRF_REPLAY_FRAME_V1"
   :world-state "WORLD_STATE_V1"
   :evidence-record "EVIDENCE_RECORD_V1"
   :evidence-chain "EVIDENCE_CHAIN_V1"
   :evidence-chain-link-v1 "EVIDENCE_CHAIN_LINK_V1"
   :run-evidence-hash-set-v1 "RUN_EVIDENCE_HASH_SET_V1"
   :evidence-hash-set "EVIDENCE_HASH_SET_V1"
   :evidence-finalization-v2 "EVIDENCE_FINALIZATION_V2"
   :runner-finalization "RUNNER_FINALIZATION_V1"
   :run-package-index "RUN_PACKAGE_INDEX_V1"
   :merkle-leaf "EVIDENCE_MERKLE_LEAF_V1"
   :merkle-node "EVIDENCE_MERKLE_NODE_V1"
   :registry "REGISTRY_V1"
   :manifest "MANIFEST_V1"
   :provenance "PROVENANCE_V1"
   :bundle-root "BUNDLE_ROOT_V1"
   :reproducibility "BENCHMARK_REPRODUCIBILITY_V1"
   :evidence-content "EVIDENCE_CONTENT_V1"
   :sensitivity-sentinel-decision "SENSITIVITY_SENTINEL_DECISION_V1"
   :state-diff "STATE_DIFF_V1"
   :protocol-state "PROTOCOL_STATE_V1"
   :params-manifest "PARAMS_MANIFEST_V1"
   :evm-projection "EVM_PROJECTION_V1"
   :invariant-attestation "INVARIANT_ATTESTATION_V1"
   :projection-evidence "PROJECTION_EVIDENCE_V1"
   :appeal-bond-semantic-state "APPEAL_BOND_SEMANTIC_STATE_V1"
   :checkpoint-evidence "CHECKPOINT_EVIDENCE_V1"
   :run-overview "RUN_OVERVIEW_V1"
   :benchmark-certification "BENCHMARK_CERTIFICATION_V1"
   :intent-dsl "INTENT_DSL_V1"
   :intent-registry-entry "INTENT_REGISTRY_ENTRY_V1"
   :intent-registry "INTENT_REGISTRY_V1"
   :projection-definition "PROJECTION_DEFINITION_V1"
   :projection-definition-registry "PROJECTION_DEFINITION_REGISTRY_V1"
   :projection-artifact "PROJECTION_ARTIFACT_V1"
   :claim-definition "CLAIM_DEFINITION"
   :claim-definition-conceptual "CONCEPT_CLAIM_DEFINITION_V1"
   :attestor "ATTESTOR"
   :evidence-node "EVIDENCE_NODE_V1"
   :decision-evidence "DECISION_EVIDENCE_V1"
   :invariant-failure "INVARIANT_FAILURE_V1"
   :startup-validation "STARTUP_VALIDATION_V1"
   :claim-result "CLAIM_RESULT_V1"
   :attestation "ATTESTATION_V1"
   :scenario "SCENARIO_V1"
   :attestation-record "ATTESTATION_RECORD_V1"
   :execution-definition "EXECUTION_DEFINITION_V1"
   :action "ACTION_V1"
   :action-at "ACTION_AT_V1"
   :pro-rata-allocation-result "PRO_RATA_ALLOCATION_RESULT_V1"
   :pro-rata-allocation-policy "PRO_RATA_ALLOCATION_POLICY_V1"
   :pro-rata-policy-outcome "PRO_RATA_POLICY_OUTCOME_V1"
   :pro-rata-proposed-effects "PRO_RATA_PROPOSED_EFFECTS_V1"
   :pro-rata-effect-refinement "PRO_RATA_EFFECT_REFINEMENT_V1"
   :pro-rata-allocation-application "PRO_RATA_ALLOCATION_APPLICATION_V1"
   :pro-rata-allocation-state-transition "PRO_RATA_ALLOCATION_STATE_TRANSITION_V1"
   :pro-rata-proof-provenance "PRO_RATA_PROOF_PROVENANCE_V1"
   :pro-rata-evm-v1 "PRO_RATA_EVM_V1"
   :pro-rata-evm-v2 "PRO_RATA_EVM_V2"
   :pro-rata-evm-conformance-v1 "PRO_RATA_EVM_CONFORMANCE_V1"
   :pro-rata-capability-output-v1 "PRO_RATA_CAPABILITY_OUTPUT_V1"
   :pro-rata-capability-output-v2 "PRO_RATA_CAPABILITY_OUTPUT_V2"
   :beneficiary-entitlement-v1 "PRF_BENEFICIARY_ENTITLEMENT_V1"
   :beneficiary-entitlement-set-v1 "PRF_BENEFICIARY_ENTITLEMENT_SET_V1"
   :entitlement-representation-descriptor-v1 "PRF_ENTITLEMENT_REPRESENTATION_DESCRIPTOR_V1"
   :pro-rata-invocation-publication-binding-v1 "PRO_RATA_INVOCATION_PUBLICATION_BINDING_V1"
   :effect-compilation-binding-v1 "EFFECT_COMPILATION_BINDING_V1"
   :effect-compilation-binding-v2 "EFFECT_COMPILATION_BINDING_V2"
   :pro-rata-effect-compilation-semantics "PRO_RATA_EFFECT_COMPILATION_SEMANTICS_V1"
   :canonical-effects-v1 "CANONICAL_EFFECTS_V1"
   :canonical-effect-state "CANONICAL_EFFECT_STATE_V1"
   :canonical-effect-set "CANONICAL_EFFECT_SET_V1"
   :canonical-quantity-identity "CANONICAL_QUANTITY_IDENTITY_V1"
   :pro-rata-effect-compilation "PRO_RATA_EFFECT_COMPILATION_V1"
   :pro-rata-effect-compilation-v2 "PRO_RATA_EFFECT_COMPILATION_V2"
   :pro-rata-effect-compilation-v3 "PRO_RATA_EFFECT_COMPILATION_V3"
   :allocation-quantity-target-map "ALLOCATION_QUANTITY_TARGET_MAP_V1"
   :allocation-quantity-target-map-v2 "ALLOCATION_QUANTITY_TARGET_MAP_V2"
   :canonical-quantity-native-location-map "CANONICAL_QUANTITY_NATIVE_LOCATION_MAP_V1"
   :allocation-quantity-target-map-validation "ALLOCATION_QUANTITY_TARGET_MAP_VALIDATION_V1"
   :allocation-quantity-target-map-validation-v2 "ALLOCATION_QUANTITY_TARGET_MAP_VALIDATION_V2"
   :sew-aggregate-held-credit-semantics "SEW_AGGREGATE_HELD_CREDIT_SEMANTICS_V1"
   :sew-aggregate-held-credit-numeric-realization-semantics "SEW_AGGREGATE_HELD_CREDIT_NUMERIC_REALIZATION_SEMANTICS_V1"
   :aggregate-custody-numeric-projection "AGGREGATE_CUSTODY_NUMERIC_PROJECTION_V1"
   :aggregate-numeric-custody-realization "AGGREGATE_NUMERIC_CUSTODY_REALIZATION_V1"
   :native-realization-adapter-descriptor "NATIVE_REALIZATION_ADAPTER_DESCRIPTOR_V1"
   :adapter-execution-context "ADAPTER_EXECUTION_CONTEXT_V1"
   :exact-native-leaf-write-set "EXACT_NATIVE_LEAF_WRITE_SET_V1"
   :actual-native-leaf-write-set "ACTUAL_NATIVE_LEAF_WRITE_SET_V1"
   :core-authorized-proposed-realization "CORE_AUTHORIZED_PROPOSED_REALIZATION_V1"
   :canonical-effect-transition "CANONICAL_EFFECT_TRANSITION_V1"
   :protocol-effect-adapter-identity "PROTOCOL_EFFECT_ADAPTER_IDENTITY_V1"
   :protocol-effect-write-set "PROTOCOL_EFFECT_WRITE_SET_V1"
   :protocol-effect-realization "PROTOCOL_EFFECT_REALIZATION_V1"
   :protocol-transaction-realization "PROTOCOL_TRANSACTION_REALIZATION_V1"
   :transact-operation "TRANSACT_OPERATION_V1"
   :transact-operations "TRANSACT_OPERATIONS_V1"
   :transact "TRANSACT_V1"
   :transact-trace "TRANSACT_TRACE_V1"
   :trace-bounded-transition "TRACE_BOUNDED_TRANSITION_V1"
   :transition-binding "TRANSITION_BINDING_V1"
   :transition-binding-semantics "TRANSITION_BINDING_SEMANTICS_V1"
   :transact-operation-footprint "TRANSACT_OPERATION_FOOTPRINT_V1"
   :authorized-effect-execution "AUTHORIZED_EFFECT_EXECUTION_V1"
   :applied-effect-receipt "APPLIED_EFFECT_RECEIPT_V1"
   :applied-adjustment-refinement "APPLIED_ADJUSTMENT_REFINEMENT_V1"
   :stability-snapshot "STABILITY_SNAPSHOT_V1"
   :benchmark-semantic-content "BENCHMARK_SEMANTIC_CONTENT_V1"
   :benchmark-registry-entry "BENCHMARK_REGISTRY_ENTRY_V1"
   :benchmark-outcome "BENCHMARK_OUTCOME_V1"
   :review-round-identity "REVIEW_ROUND_IDENTITY_V1"
   :review-governance-v1 "REVIEW_GOVERNANCE_V1"
   :review-position-acceptance-v1 "REVIEW_POSITION_ACCEPTANCE_V1"
   :position-time-basis-v1 "POSITION_TIME_BASIS_V1"
   :review-governance-admissibility-v1 "REVIEW_GOVERNANCE_ADMISSIBILITY_V1"
   :governed-authority-resolution-basis-v1 "GOVERNED_AUTHORITY_RESOLUTION_BASIS_V1"
   :resolved-review-authority-context-v1 "RESOLVED_REVIEW_AUTHORITY_CONTEXT_V1"
   :governed-authority-transition-binding-v1 "GOVERNED_AUTHORITY_TRANSITION_BINDING_V1"
   :authoritative-state-envelope-v1 "AUTHORITATIVE_STATE_ENVELOPE_V1"
   :authoritative-state-envelope-v2 "AUTHORITATIVE_STATE_ENVELOPE_V2"
   :governed-authority-resolver-v1 "GOVERNED_AUTHORITY_RESOLVER_V1"
   :governed-authority-semantics-v1 "GOVERNED_AUTHORITY_SEMANTICS_V1"
   :governed-authority-resolution-basis-v2 "GOVERNED_AUTHORITY_RESOLUTION_BASIS_V2"
   :governed-authority-signer-key-set-v1 "GOVERNED_AUTHORITY_SIGNER_KEY_SET_V1"
   :governed-researcher-decision-submission-v1 "GOVERNED_RESEARCHER_DECISION_SUBMISSION_V1"
   :governed-authority-key-resolution-v1 "GOVERNED_AUTHORITY_KEY_RESOLUTION_V1"
   :governed-authority-signing-request-v1 "GOVERNED_AUTHORITY_SIGNING_REQUEST_V1"
   :governed-authority-transition-definition-v1 "GOVERNED_AUTHORITY_TRANSITION_DEFINITION_V1"
   :authoritative-material-state-v1 "AUTHORITATIVE_MATERIAL_STATE_V1"
   :governed-authority-content-transition-v1 "GOVERNED_AUTHORITY_CONTENT_TRANSITION_V1"
   :governed-authority-derived-result-receipt-v1 "GOVERNED_AUTHORITY_DERIVED_RESULT_RECEIPT_V1"
   :governed-authority-signing-request-signature-v1 "GOVERNED_AUTHORITY_SIGNING_REQUEST_SIGNATURE_V1"
   :custody-signing-receipt-v1 "CUSTODY_SIGNING_RECEIPT_V1"
   :researcher-decision-k3 "RESEARCHER_DECISION_K3"
   :governed-authority-review-round-v1 "GOVERNED_AUTHORITY_REVIEW_ROUND_V1"
   :governed-authority-evaluation-basis-v1 "GOVERNED_AUTHORITY_EVALUATION_BASIS_V1"
   :governed-authority-position-time-index-v1 "GOVERNED_AUTHORITY_POSITION_TIME_INDEX_V1"
   :researcher-run-report "RESEARCHER_RUN_REPORT_V1"
   :replication-observation-set "REPLICATION_OBSERVATION_SET_V1"
   :researcher-position "RESEARCHER_POSITION_V1"
   :three-member-certificate "THREE_MEMBER_CERTIFICATE_V1"
   :evidence-collection "EVIDENCE_COLLECTION_V1"
   :state-projection "STATE_PROJECTION_V1"
   :research-framework-change-proposal "RESEARCH_FRAMEWORK_CHANGE_PROPOSAL_V1"
   :changelog-challenge "CHANGELOG_CHALLENGE_V1"
   :research-benchmark-model "RESEARCH_BENCHMARK_MODEL_V1"
   :research-theorem-outcome "RESEARCH_THEOREM_OUTCOME_V1"
   :research-conclusion "RESEARCH_CONCLUSION_V1"
   :research-command "RESEARCH_COMMAND_V1"
   :research-command-trace-v2 "RESEARCH_COMMAND_TRACE_V2"
   :dimension-support-v1 "DIMENSION_SUPPORT_V1"
   :research-assignment "RESEARCH_ASSIGNMENT_V1"
   :research-assignment-solidity-target "RESEARCH_ASSIGNMENT_SOLIDITY_TARGET_V1"
   :research-assignment-target-binding "RESEARCH_ASSIGNMENT_TARGET_BINDING_V1"
   :researcher-reward-policy "RESEARCHER_REWARD_POLICY_V1"
   :researcher-reward-eligibility "RESEARCHER_REWARD_ELIGIBILITY_V1"
   :researcher-reward-proposal "RESEARCHER_REWARD_PROPOSAL_V1"
   :researcher-reward-obligation "RESEARCHER_REWARD_OBLIGATION_V1"
   :researcher-reward-key "RESEARCHER_REWARD_KEY_V1"
   :research-claim-acceptance-policy "RESEARCH_CLAIM_ACCEPTANCE_POLICY_V1"
   :research-claim-acceptance "RESEARCH_CLAIM_ACCEPTANCE_V1"
   :research-claim-lifecycle-transition "RESEARCH_CLAIM_LIFECYCLE_TRANSITION_V1"
   :research-claim-lifecycle-state "RESEARCH_CLAIM_LIFECYCLE_STATE_V1"
   :incentive-model "INCENTIVE_MODEL_V1"
   :incentive-deviation-domain "INCENTIVE_DEVIATION_DOMAIN_V1"
   :research-analysis-closure "RESEARCH_ANALYSIS_CLOSURE_V1"
   :research-analysis-output "RESEARCH_ANALYSIS_OUTPUT_V1"
   :research-analysis-result "RESEARCH_ANALYSIS_RESULT_V1"
   :research-analysis-result-descriptor "RESEARCH_ANALYSIS_RESULT_DESCRIPTOR_V1"
   :research-analysis-verification "RESEARCH_ANALYSIS_VERIFICATION_V1"
   :research-analysis-comparison-v1 "RESEARCH_ANALYSIS_COMPARISON_V1"
   :research-analysis-composition-v1 "RESEARCH_ANALYSIS_COMPOSITION_V1"
   :research-analytical-claim "RESEARCH_ANALYTICAL_CLAIM_V1"
   :research-analytical-claim-v2 "RESEARCH_ANALYTICAL_CLAIM_V2"
   :runtime-profile "RUNTIME_PROFILE_V1"
   :claimant-execution-observation "CLAIMANT_EXECUTION_OBSERVATION_V1"
   :research-execution "RESEARCH_EXECUTION_V1"
   :research-execution-cell-v1 "RESEARCH_EXECUTION_CELL_V1"
   :research-execution-manifest-v1 "RESEARCH_EXECUTION_MANIFEST_V1"
   :research-execution-cell-result-v1 "RESEARCH_EXECUTION_CELL_RESULT_V1"
   :research-execution-policy-analysis-v1 "RESEARCH_EXECUTION_POLICY_ANALYSIS_V1"
   :research-execution-researcher-axis-v1 "RESEARCH_EXECUTION_RESEARCHER_AXIS_V1"
   :distributed-experiment-profile-v1 "DISTRIBUTED_EXPERIMENT_PROFILE_V1"
   :distributed-scheduler-policy-v1 "DISTRIBUTED_SCHEDULER_POLICY_V1"
   :distributed-dependency-set-v1 "DISTRIBUTED_DEPENDENCY_SET_V1"
   :distributed-placement-projection-v1 "DISTRIBUTED_PLACEMENT_PROJECTION_V1"
   :distributed-execution-attempt-v1 "DISTRIBUTED_EXECUTION_ATTEMPT_V1"
   :distributed-execution-failure-receipt-v1 "DISTRIBUTED_EXECUTION_FAILURE_RECEIPT_V1"
   :distributed-scheduler-run-v1 "DISTRIBUTED_SCHEDULER_RUN_V1"
   :research-execution-environment-v1 "RESEARCH_EXECUTION_ENVIRONMENT_V1"
   :runner-participation-v1 "RUNNER_PARTICIPATION_V1"
   :research-execution-policy-v1 "RESEARCH_EXECUTION_POLICY_V1"
   :research-execution-job-v1 "RESEARCH_EXECUTION_JOB_V1"
   :research-run-slot-v1 "RESEARCH_RUN_SLOT_V1"
   :research-run-assignment-v1 "RESEARCH_RUN_ASSIGNMENT_V1"
   :research-run-evidence-v1 "RESEARCH_RUN_EVIDENCE_V1"
   :research-dependency-manifest-v1 "RESEARCH_DEPENDENCY_MANIFEST_V1"
   :research-dependency-policy-v1 "RESEARCH_DEPENDENCY_POLICY_V1"
   :resolved-research-dependency-set-v1 "RESOLVED_RESEARCH_DEPENDENCY_SET_V1"
   :research-implementation-identity-v1 "RESEARCH_IMPLEMENTATION_IDENTITY_V1"
   :research-execution-assurance-policy-v1 "RESEARCH_EXECUTION_ASSURANCE_POLICY_V1"
   :research-execution-job-assurance-v1 "RESEARCH_EXECUTION_JOB_ASSURANCE_V1"
   :research-participant-set-v1 "RESEARCH_PARTICIPANT_SET_V1"
   :research-fixed-validation-receipt-v1 "RESEARCH_FIXED_VALIDATION_RECEIPT_V1"
   :research-run-assurance-evidence-v1 "RESEARCH_RUN_ASSURANCE_EVIDENCE_V1"
   :research-proof-generation-receipt-v1 "RESEARCH_PROOF_GENERATION_RECEIPT_V1"
   :research-proof-program-identity-v1 "RESEARCH_PROOF_PROGRAM_IDENTITY_V1"
   :research-proof-system-identity-v1 "RESEARCH_PROOF_SYSTEM_IDENTITY_V1"
   :research-sp1-proof-verification-v1 "RESEARCH_SP1_PROOF_VERIFICATION_V1"
   :claim-to-relation-v1 "CLAIM_TO_RELATION_V1"
   :claim-target-aggregate-v1 "CLAIM_TARGET_AGGREGATE_V1"
   :possession-position-v1 "POSSESSION_POSITION_V1"
   :accounting-position-v1 "ACCOUNTING_POSITION_V1"
   :accounting-reduction-contract-v1 "ACCOUNTING_REDUCTION_CONTRACT_V1"
   :accounting-request-v1 "ACCOUNTING_REQUEST_V1"
   :accounting-work-unit-v1 "ACCOUNTING_WORK_UNIT_V1"
   :accounting-partition-plan-v1 "ACCOUNTING_PARTITION_PLAN_V1"
   :accounting-partial-result-v1 "ACCOUNTING_PARTIAL_RESULT_V1"
   :accounting-reconciliation-v1 "ACCOUNTING_RECONCILIATION_V1"
   :canonical-accounting-result-v1 "CANONICAL_ACCOUNTING_RESULT_V1"
   :canonical-accounting-partial-v1 "CANONICAL_ACCOUNTING_PARTIAL_V1"
   :accounting-proof-backed-admission-v1 "ACCOUNTING_PROOF_BACKED_ADMISSION_V1"
   :research-axis-semantics-v1 "RESEARCH_AXIS_SEMANTICS_V1"
   :research-coordinate-interaction-v1 "RESEARCH_COORDINATE_INTERACTION_V1"
   :coordinate-derived-result-v1 "COORDINATE_DERIVED_RESULT_V1"
   :researcher-evidence-attribution-v1 "RESEARCHER_EVIDENCE_ATTRIBUTION_V1"
   :research-participant-assurance-v1 "RESEARCH_PARTICIPANT_ASSURANCE_V1"
   :research-native-execution-environment-v1 "RESEARCH_NATIVE_EXECUTION_ENVIRONMENT_V1"
   :research-native-accounting-implementation-v1 "RESEARCH_NATIVE_ACCOUNTING_IMPLEMENTATION_V1"
   :research-native-accounting-work-v1 "RESEARCH_NATIVE_ACCOUNTING_WORK_V1"
   :research-native-accounting-run-v1 "RESEARCH_NATIVE_ACCOUNTING_RUN_V1"
   :research-native-accounting-validation-v1 "RESEARCH_NATIVE_ACCOUNTING_VALIDATION_V1"
   :research-dependency-closed-interaction-implementation-v1
   "RESEARCH_DEPENDENCY_CLOSED_INTERACTION_IMPLEMENTATION_V1"
   :research-dependency-closed-source-v1 "RESEARCH_DEPENDENCY_CLOSED_SOURCE_V1"
   :research-dependency-closed-resolution-v1 "RESEARCH_DEPENDENCY_CLOSED_RESOLUTION_V1"
   :research-dependency-closed-axis-v1 "RESEARCH_DEPENDENCY_CLOSED_AXIS_V1"
   :research-dependency-closed-observation-v1
   "RESEARCH_DEPENDENCY_CLOSED_OBSERVATION_V1"
   :research-job-cancellation-v1 "RESEARCH_JOB_CANCELLATION_V1"
   :research-realized-reachability-v1 "RESEARCH_REALIZED_REACHABILITY_V1"
   :research-runner-control-observation-v1 "RESEARCH_RUNNER_CONTROL_OBSERVATION_V1"
   :research-work-lifecycle-event-v1 "RESEARCH_WORK_LIFECYCLE_EVENT_V1"
   :research-cancellation-policy-v1 "RESEARCH_CANCELLATION_POLICY_V1"
   :research-proof-verification-evidence-v1 "RESEARCH_PROOF_VERIFICATION_EVIDENCE_V1"
   :research-execution-sufficiency-policy-v1 "RESEARCH_EXECUTION_SUFFICIENCY_POLICY_V1"
   :research-execution-sufficiency-evaluation-v1 "RESEARCH_EXECUTION_SUFFICIENCY_EVALUATION_V1"
   :research-execution-control-analysis-v1 "RESEARCH_EXECUTION_CONTROL_ANALYSIS_V1"
   :research-execution-environment-observation-v1 "RESEARCH_EXECUTION_ENVIRONMENT_OBSERVATION_V1"
   :research-anvil-execution-receipt-v1 "RESEARCH_ANVIL_EXECUTION_RECEIPT_V1"
   :research-observed-fixed-validation-receipt-v1 "RESEARCH_OBSERVED_FIXED_VALIDATION_RECEIPT_V1"
   :research-observed-run-evidence-v1 "RESEARCH_OBSERVED_RUN_EVIDENCE_V1"
   :research-observed-execution-work-v1 "RESEARCH_OBSERVED_EXECUTION_WORK_V1"
   :research-accounting-execution-work-v1 "RESEARCH_ACCOUNTING_EXECUTION_WORK_V1"
   :research-accounting-word-document-v1 "RESEARCH_ACCOUNTING_WORD_DOCUMENT_V1"
   :research-word-partition-plan-v1 "RESEARCH_WORD_PARTITION_PLAN_V1"
   :research-word-work-unit-v1 "RESEARCH_WORD_WORK_UNIT_V1"
   :research-word-assignment-v1 "RESEARCH_WORD_ASSIGNMENT_V1"
   :research-word-observation-v1 "RESEARCH_WORD_OBSERVATION_V1"
   :research-word-reconciliation-v1 "RESEARCH_WORD_RECONCILIATION_V1"
   :research-word-sequence-v1 "RESEARCH_WORD_SEQUENCE_V1"
   :research-word-accounting-basis-v1 "RESEARCH_WORD_ACCOUNTING_BASIS_V1"
   :research-accounting-basis-comparison-v1 "RESEARCH_ACCOUNTING_BASIS_COMPARISON_V1"
   :research-accounting-implementation-comparison-v1
   "RESEARCH_ACCOUNTING_IMPLEMENTATION_COMPARISON_V1"
   :research-observation-work-plan-v1 "RESEARCH_OBSERVATION_WORK_PLAN_V1"
   :research-observation-work-unit-v1 "RESEARCH_OBSERVATION_WORK_UNIT_V1"
   :research-observation-assignment-v1 "RESEARCH_OBSERVATION_ASSIGNMENT_V1"
   :research-coordinate-observation-v1 "RESEARCH_COORDINATE_OBSERVATION_V1"
   :research-observation-reconciliation-v1 "RESEARCH_OBSERVATION_RECONCILIATION_V1"
   :research-claim-evidence-plan-v1 "RESEARCH_CLAIM_EVIDENCE_PLAN_V1"
   :research-claim-evidence-source-result-v1 "RESEARCH_CLAIM_EVIDENCE_SOURCE_RESULT_V1"
   :research-claim-evidence-coordinate-v1 "RESEARCH_CLAIM_EVIDENCE_COORDINATE_V1"
   :research-claim-evidence-assignment-v1 "RESEARCH_CLAIM_EVIDENCE_ASSIGNMENT_V1"
   :research-claim-evidence-coordinate-result-v1 "RESEARCH_CLAIM_EVIDENCE_COORDINATE_RESULT_V1"
   :research-claim-evidence-observation-v1 "RESEARCH_CLAIM_EVIDENCE_OBSERVATION_V1"
   :research-claim-evidence-manifest-v1 "RESEARCH_CLAIM_EVIDENCE_MANIFEST_V1"
   :research-claim-evidence-reconciliation-v1 "RESEARCH_CLAIM_EVIDENCE_RECONCILIATION_V1"
   :reproduction-input-v1 "REPRODUCTION_INPUT_V1"
   :reproduction-execution-v1 "REPRODUCTION_EXECUTION_V1"
   :reproduction-evidence-v1 "REPRODUCTION_EVIDENCE_V1"
   :reproduction-qualification-witness-v1 "REPRODUCTION_QUALIFICATION_WITNESS_V1"
   :reproduction-disagreement-witness-v1 "REPRODUCTION_DISAGREEMENT_WITNESS_V1"
   :research-declared-accounting-row-v1 "RESEARCH_DECLARED_ACCOUNTING_ROW_V1"
   :research-observed-run-proof-statement-v1 "RESEARCH_OBSERVED_RUN_PROOF_STATEMENT_V1"
   :anvil-runtime-code-v1 "ANVIL_RUNTIME_CODE_V1"
   :anvil-state-projection-v1 "ANVIL_STATE_PROJECTION_V1"
   :anvil-executed-action-v1 "ANVIL_EXECUTED_ACTION_V1"
   :anvil-semantic-result-v1 "ANVIL_SEMANTIC_RESULT_V1"
   :research-benchmark-pack "RESEARCH_BENCHMARK_PACK_V1"
   :research-benchmark-pack-v2 "RESEARCH_BENCHMARK_PACK_V2"
   :creation-provenance "CREATION_PROVENANCE_V1"
   :source-creation "SOURCE_CREATION_V1"
   :trust-sequence-definition "TRUST_SEQUENCE_DEFINITION_V1"
   :procedure-execution-witness "PROCEDURE_EXECUTION_WITNESS_V1"
   :research-force-authorisation "RESEARCH_FORCE_AUTHORISATION_V1"
   :researcher-decision "RESEARCHER_DECISION_V1"
   :researcher-decision-v2 "RESEARCHER_DECISION_V2"
   :researcher-decision-scope "RESEARCHER_DECISION_SCOPE_V1"
   :decision-subject "DECISION_SUBJECT_V1"
   :cancellation-binding "CANCELLATION_BINDING_V1"
   :cancellation-operation "CANCELLATION_OPERATION_V1"
   :cancellation-attempt "CANCELLATION_ATTEMPT_V1"
   :cancellation-execution "CANCELLATION_EXECUTION_V1"
   :cancellation-evaluation-inputs "CANCELLATION_EVALUATION_INPUTS_V1"
   :cancellation-derivation "CANCELLATION_DERIVATION_V1"
   :three-member-authority-report "THREE_MEMBER_AUTHORITY_REPORT_V1"
   :canonical-value-sequence "CANONICAL_VALUE_SEQUENCE_V1"
   :prf-commitment-composition-v1 "PRF_COMMITMENT_COMPOSITION_V1"
   :sew-resolver-ladder-v1 "SEW_RESOLVER_LADDER_V1"
   :sew-action-root "SEW_ACTION_ROOT_V1"
   :sew-request-id-v1 "SEW_REQUEST_ID_V1"
   :sew-compound-action-member-v1 "SEW_COMPOUND_ACTION_MEMBER_V1"
   :sew-compound-action-v1 "SEW_COMPOUND_ACTION_V1"
   :sew-compound-action-lineage-v1 "SEW_COMPOUND_ACTION_LINEAGE_V1"
   :allocation-assurance-certificate "ALLOCATION_ASSURANCE_CERTIFICATE_V1"
   :force-authorisation-reservation "FORCE_AUTHORISATION_RESERVATION_V1"
   :force-authorisation-consumption "FORCE_AUTHORISATION_CONSUMPTION_V1"
   :force-authorisation-consumption-v2 "FORCE_AUTHORISATION_CONSUMPTION_V2"
   :claim-consumption-receipt "CLAIM_CONSUMPTION_RECEIPT_V1"
   :force-authorised-execution-evidence "FORCE_AUTHORISED_EXECUTION_EVIDENCE_V1"
   :force-authorised-execution-evidence-v2 "FORCE_AUTHORISED_EXECUTION_EVIDENCE_V2"
   :authorised-effect-correlation "AUTHORISED_EFFECT_CORRELATION_V1"
   :sew-terminal-state-snapshot "SEW_TERMINAL_STATE_SNAPSHOT_V1"
   :sew-resolution-basis-v1 "SEW_RESOLUTION_BASIS_V1"
   :sew-resolution-decision-v1 "SEW_RESOLUTION_DECISION_V1"
   :sew-adjudicator-binding-v1 "SEW_ADJUDICATOR_BINDING_V1"
   :sew-resolution-live-commitment-v1 "SEW_RESOLUTION_LIVE_COMMITMENT_V1"
   :sew-adjudication-snapshot-v1 "SEW_ADJUDICATION_SNAPSHOT_V1"
   :sew-adjudication-source-envelope-v1 "SEW_ADJUDICATION_SOURCE_ENVELOPE_V1"
   :sew-dispute-evidence-set-v1 "SEW_DISPUTE_EVIDENCE_SET_V1"
   :sew-dispute-question-v1 "SEW_DISPUTE_QUESTION_V1"
   :sew-ruling-schema-v1 "SEW_RULING_SCHEMA_V1"
   :sew-adjudication-policy-v1 "SEW_ADJUDICATION_POLICY_V1"
   :sew-adjudication-case-definition-v1 "SEW_ADJUDICATION_CASE_DEFINITION_V1"
   :sew-adjudication-case-v1 "SEW_ADJUDICATION_CASE_V1"
   :sew-adjudication-case-subject-v1 "SEW_ADJUDICATION_CASE_SUBJECT_V1"
   :sew-adjudication-case-fence-v1 "SEW_ADJUDICATION_CASE_FENCE_V1"
   :sew-adjudication-instance-v1 "SEW_ADJUDICATION_INSTANCE_V1"
   :sew-adjudication-temporal-basis-v1 "SEW_ADJUDICATION_TEMPORAL_BASIS_V1"
   :sew-protocol-instance-v1 "SEW_PROTOCOL_INSTANCE_V1"
   :prf-adjudication-basis-v1 "PRF_ADJUDICATION_BASIS_V1"
   :prf-adjudication-authentication-verification-v1 "PRF_ADJUDICATION_AUTHENTICATION_VERIFICATION_V1"
   :prf-adjudication-decision-v1 "PRF_ADJUDICATION_DECISION_V1"
   :prf-adjudicator-identity-v1 "PRF_ADJUDICATOR_IDENTITY_V1"
   :prf-adjudication-transition-eligibility-v1 "PRF_ADJUDICATION_TRANSITION_ELIGIBILITY_V1"
   :prf-adjudication-transition-selection-basis-v1 "PRF_ADJUDICATION_TRANSITION_SELECTION_BASIS_V1"
   :prf-adjudication-transition-selection-result-v1 "PRF_ADJUDICATION_TRANSITION_SELECTION_RESULT_V1"
   :prf-adjudication-authority-transition-v1 "PRF_ADJUDICATION_AUTHORITY_TRANSITION_V1"
   :prf-dispute-ruling-v1 "PRF_DISPUTE_RULING_V1"
   :prf-dispute-ruling-finality-v1 "PRF_DISPUTE_RULING_FINALITY_V1"
   :prf-dispute-resolution-closure-v1 "PRF_DISPUTE_RESOLUTION_CLOSURE_V1"
   :prf-dispute-resolution-terminal-envelope-v1 "PRF_DISPUTE_RESOLUTION_TERMINAL_ENVELOPE_V1"
   :sew-dispute-resolution-post-settlement-state-v1 "SEW_DISPUTE_RESOLUTION_POST_SETTLEMENT_STATE_V1"
   :sew-authenticated-ruling-resolution-v1 "SEW_AUTHENTICATED_RULING_RESOLUTION_V1"
   :staged-event-evidence "STAGED_EVENT_EVIDENCE_V1"
   :terminal-evidence-publication "TERMINAL_EVIDENCE_PUBLICATION_V1"
   :consensus-terminal-reservation "CONSENSUS_TERMINAL_RESERVATION_V1"
   :generated-case-set "GENERATED_CASE_SET_V1"
   :benchmark-manifest "BENCHMARK_MANIFEST_V1"
   :research-definition "RESEARCH_DEFINITION_V1"
   :research-axis "RESEARCH_AXIS_V1"
   :research-definition-diff "RESEARCH_DEFINITION_DIFF_V1"
   :research-execution-projection "RESEARCH_EXECUTION_PROJECTION_V1"
   :research-observation-projection "RESEARCH_OBSERVATION_PROJECTION_V1"
   :available-actions-observation "AVAILABLE_ACTIONS_OBSERVATION_V1"
   :pro-rata-research-observation "PRO_RATA_RESEARCH_OBSERVATION_V1"
   :research-execution-plan "RESEARCH_EXECUTION_PLAN_V1"
   :pro-rata-allocation-evidence "PRO_RATA_ALLOCATION_EVIDENCE_V1"
   :pro-rata-application-evidence "PRO_RATA_APPLICATION_EVIDENCE_V1"
   :pro-rata-execution-evidence "PRO_RATA_EXECUTION_EVIDENCE_V1"
   :pro-rata-execution-evidence-v2 "PRO_RATA_EXECUTION_EVIDENCE_V2"
   :slash-distribution-policy-v1 "SLASH_DISTRIBUTION_POLICY_V1"
   :slash-distribution-v1 "SLASH_DISTRIBUTION_V1"
   :slash-distribution-application-receipt-v1 "SLASH_DISTRIBUTION_APPLICATION_RECEIPT_V1"
   :fixed-regression-case-v1 "FIXED_REGRESSION_CASE_V1"
   :slash-distribution-application-plan-v1 "SLASH_DISTRIBUTION_APPLICATION_PLAN_V1"
   :slash-distribution-application-plan-v2 "SLASH_DISTRIBUTION_APPLICATION_PLAN_V2"
   :prf-effect-contract-v1 "PRF_EFFECT_CONTRACT_V1"
   :bounty-payable-v1 "BOUNTY_PAYABLE_V1"
   :bounty-payable-backing-v1 "BOUNTY_PAYABLE_BACKING_V1"
   :review-member-canonical-indices "REVIEW_MEMBER_CANONICAL_INDICES_V1"
   :review-member-canonical-indices-entries "REVIEW_MEMBER_CANONICAL_INDICES_ENTRIES_V1"
   :pool-availability-v2 "POOL_AVAILABILITY_V2"
   :pool-reservation "POOL_RESERVATION_V1"
   :shortfall-context "PRF_SHORTFALL_CONTEXT_V1"
   :award-calculation-v2 "AWARD_CALCULATION_V2"
   :claim-set "CLAIM_SET_V1"
   :check-set "CHECK_SET_V1"
   :award-policy "AWARD_POLICY_V1"
   :priority-order-v1 "PRIORITY_ORDER_V1"
   :overflow-capability "OVERFLOW_CAPABILITY_V1"
   :overflow-authorisation-scope "OVERFLOW_AUTHORISATION_SCOPE_V1"
   :overflow-capacity-context "OVERFLOW_CAPACITY_CONTEXT_V1"
   :with-bounty-policy-v1 "WITH_BOUNTY_POLICY_V1"
   :with-bounty-invocation-v1 "WITH_BOUNTY_INVOCATION_V1"
   :with-bounty-obligation-v1 "WITH_BOUNTY_OBLIGATION_V1"
   :with-bounty-effect-v1 "WITH_BOUNTY_EFFECT_V1"
   :with-bounty-effect-set-v1 "WITH_BOUNTY_EFFECT_SET_V1"
   :with-bounty-application-plan-v1 "WITH_BOUNTY_APPLICATION_PLAN_V1"
   :with-bounty-transition-evidence-v1 "WITH_BOUNTY_TRANSITION_EVIDENCE_V1"
   :with-bounty-verification-basis-v1 "WITH_BOUNTY_VERIFICATION_BASIS_V1"
   :with-bounty-public-result-v1 "WITH_BOUNTY_PUBLIC_RESULT_V1"
   :allocation-context "ALLOCATION_CONTEXT_V1"
   :claimant-set "CLAIMANT_SET_V1"
   :outcome-set "OUTCOME_SET_V1"
   :proposed-rates "PROPOSED_RATES_V1"
   :rate-derived-summary "RATE_DERIVED_SUMMARY_V1"
   :selected-outcome "SELECTED_OUTCOME_V1"
   :result-root "RESULT_ROOT_V1"
   :certificate-assertions "CERTIFICATE_ASSERTIONS_V1"
   :certificate-assertions-v2 "CERTIFICATE_ASSERTIONS_V2"
   :lab-parameter-root "LAB_PARAMETER_ROOT_V1"
   :lab-withdrawal-fcfs "LAB_WITHDRAWAL_FCFS_V1"
   :fail-action-policy "FAIL_ACTION_POLICY_V1"
   :realized-allocation-statement "REALIZED_ALLOCATION_STATEMENT_V1"
   :realized-request-set "REALIZED_REQUEST_SET_V1"
   :allocation-policy "ALLOCATION_POLICY_V1"
   :realized-results "REALIZED_RESULTS_V1"
   :round-lifecycle "ROUND_LIFECYCLE_V1"
   :scenario-evidence-binding "SCENARIO_EVIDENCE_BINDING_V1"
   :allocation-activation "ALLOCATION_ACTIVATION_V1"
   :allocation-activation-policy "ALLOCATION_ACTIVATION_POLICY_V1"
   :confidence-composition-v1 "CONFIDENCE_COMPOSITION_V1"
   :research-command-trace-v1 "RESEARCH_COMMAND_TRACE_V1"
   :extension-envelope-shape-v1 "EXTENSION_ENVELOPE_SHAPE_V1"
   :extension-lockfile-v1 "EXTENSION_LOCKFILE_V1"
   :extension-resolution-v1 "EXTENSION_RESOLUTION_V1"
   :extension-registry-v1 "EXTENSION_REGISTRY_V1"
   :extension-capability-descriptor-v1 "EXTENSION_CAPABILITY_DESCRIPTOR_V1"
   :extension-package-manifest-v1 "EXTENSION_PACKAGE_MANIFEST_V1"
   :held-custody-override-selection "HELD_CUSTODY_OVERRIDE_SELECTION_V1"
   :held-override-lineage-v1 "HELD_OVERRIDE_LINEAGE_V1"
   :held-override-consumption "HELD_OVERRIDE_CONSUMPTION_V1"
   :held-override-successor-state "HELD_OVERRIDE_SUCCESSOR_STATE_V1"
   :benchmark-conservation-v1 "BENCHMARK_CONSERVATION_V1"
   :benchmark-input-set-v1 "BENCHMARK_INPUT_SET_V1"
   :benchmark-content-registry-v1 "BENCHMARK_CONTENT_REGISTRY_V1"
   :benchmark-finalization-v1 "BENCHMARK_FINALIZATION_V1"
   :suite-definition-v1 "SUITE_DEFINITION_V1"
   :native-exact-replication-v1 "NATIVE_EXACT_REPLICATION_V1"
   :conformance-reproduction-lineage-v1 "conformance.reproduction-lineage.v1"
   :conformance-validator-implementation-v1 "conformance.validator-implementation.v1"
   :evidence-package-admission-v1 "evidence-package-admission.v1"
   :benchmark-execution-descriptor-v1 "BENCHMARK_EXECUTION_DESCRIPTOR_V1"
   :benchmark-execution-parameters-v1 "BENCHMARK_EXECUTION_PARAMETERS_V1"
   :benchmark-execution-protocol-config-v1 "BENCHMARK_EXECUTION_PROTOCOL_CONFIG_V1"
   :claim-outcome-v1 "CLAIM_OUTCOME_V1"
   :community-attestation-v0 "COMMUNITY_ATTESTATION_V0"
   :community-code-v0 "COMMUNITY_CODE_V0"
   :community-env-v0 "COMMUNITY_ENV_V0"
   :community-finding-v0 "COMMUNITY_FINDING_V0"
   :community-mailbox-v0 "COMMUNITY_MAILBOX_V0"
   :community-stable-result-v0 "COMMUNITY_STABLE_RESULT_V0"
   :community-task-v0 "COMMUNITY_TASK_V0"
   :comparability-shared-v1 "COMPARABILITY_SHARED_V1"
   :composition-combination-v1 "COMPOSITION_COMBINATION_V1"
   :composition-contract-v1 "COMPOSITION_CONTRACT_V1"
   :composition-plan-v1 "COMPOSITION_PLAN_V1"
   :default-build-attestation-v1 "DEFAULT_BUILD_ATTESTATION_V1"
   :default-build-smoke-output-v1 "DEFAULT_BUILD_SMOKE_OUTPUT_V1"
   :deferral-v1 "DEFERRAL_V1"
   :evidence-graph-v1 "EVIDENCE_GRAPH_V1"
   :held-adjustment-v1 "HELD_ADJUSTMENT_V1"
   :prf-artifact-publish-decision-v1 "PRF_ARTIFACT_PUBLISH_DECISION_V1"
   :prf-artifact-publish-manifest-v1 "PRF_ARTIFACT_PUBLISH_MANIFEST_V1"
   :prf-artifact-publish-request-v1 "PRF_ARTIFACT_PUBLISH_REQUEST_V1"
   :prf-authorisation-instance-v1 "PRF_AUTHORISATION_INSTANCE_V1"
   :prf-authorisation-provenance-v1 "PRF_AUTHORISATION_PROVENANCE_V1"
   :prf-contract-schema-v1 "PRF_CONTRACT_SCHEMA_V1"
   :prf-force-authorisation-policy-v1 "PRF_FORCE_AUTHORISATION_POLICY_V1"
   :prf-release-attestation-payload-v1 "PRF_RELEASE_ATTESTATION_PAYLOAD_V1"
   :prf-resubmission-issue-request-v1 "PRF_RESUBMISSION_ISSUE_REQUEST_V1"
   :prf-resubmission-issue-request-v2 "PRF_RESUBMISSION_ISSUE_REQUEST_V2"
   :prf-sensitivity-sentinel-decision-v1 "PRF_SENSITIVITY_SENTINEL_DECISION_V1"
   :prf-sensitivity-sentinel-projection-v1 "PRF_SENSITIVITY_SENTINEL_PROJECTION_V1"
   :prf-sensitivity-sentinel-request-v1 "PRF_SENSITIVITY_SENTINEL_REQUEST_V1"
   :prf-verdict-policy-v1 "PRF_VERDICT_POLICY_V1"
   :pro-rata-evaluation-v1 "PRO_RATA_EVALUATION_V1"
   :scenario-distribution-v1 "SCENARIO_DISTRIBUTION_V1"
   :var-projection-v1 "VAR_PROJECTION_V1"
   :workflow-group-v1 "WORKFLOW_GROUP_V1"
   :workflow-group-member-v1 "WORKFLOW_GROUP_MEMBER_V1"
   :conformance-bundle-v1 "conformance.bundle.v1"
   :conformance-derivation-chain-v1 "conformance.derivation-chain.v1"
   :conformance-profile-v1 "conformance.profile.v1"
   :conformance-signature-verification-v1 "conformance.signature-verification.v1"
   :conformance-subject-set-v1 "conformance.subject-set.v1"
   :conformance-validation-subject-v1 "conformance.validation-subject.v1"
   :force-authorisation-scope "force-authorisation-scope"
   :prf-attempt-disposition-v1 "prf.attempt-disposition.v1"
   :prf-attempt-acceptance-definition-v1 "prf.attempt-acceptance-definition.v1"
   :prf-attempt-acceptance-authority-basis-v1 "prf.attempt-acceptance-authority-basis.v1"
   :prf-attempt-publisher-authority-v1 "prf.attempt-publisher-authority.v1"
   :prf-attempt-submission-registry-v1 "prf.attempt-submission-registry.v1"
   :prf-attempt-results-artifact-v1 "prf.attempt-results-artifact.v1"
   :prf-attempt-publisher-statement-v1 "prf.attempt-publisher-statement.v1"
   :prf-attempt-publisher-envelope-v1 "prf.attempt-publisher-envelope.v1"
   :prf-attempt-execution-evidence-subject-v1 "prf.attempt-execution-evidence-subject.v1"
   :prf-attempt-certificate-verification-subject-v1 "prf.attempt-certificate-verification-subject.v1"
   :prf-acceptance-attempt-subject-v1 "prf.acceptance-attempt-subject.v1"
   :prf-acceptance-evaluation-v1 "prf.acceptance-evaluation.v1"
   :prf-acceptance-evaluation-v2 "prf.acceptance-evaluation.v2"
   :prf-acceptance-finding-v1 "prf.acceptance-finding.v1"
   :prf-authority-registries-verifiable-v1 "prf.authority-registries-verifiable.v1"
   :prf-verifier-registry-selection-v1 "prf.verifier-registry-selection.v1"
   :prf-results-binding-v1 "prf.results-binding.v1"
   :prf-researcher-resubmission-v1 "prf.researcher-resubmission.v1"
   :prf-resubmission-chain-state-v1 "prf.resubmission-chain-state.v1"
   :prf-resubmission-family-v1 "prf.resubmission-family.v1"
   :prf-resubmission-idempotency-v1 "prf.resubmission-idempotency.v1"
   :prf-submission-attempt-receipt-v1 "prf.submission-attempt-receipt.v1"
   :prf-submission-attempt-receipt-v2 "prf.submission-attempt-receipt.v2"
   :prf-resubmission-receipt-obligation-v1 "prf.resubmission-receipt-obligation.v1"
   :prf-submission-basis-v1 "prf.submission-basis.v1"
   :prf-submission-bundle-v1 "prf.submission-bundle.v1"
   :prf-transaction-effects-v1 "prf.transaction-effects.v1"
   :prf-transaction-input-v1 "prf.transaction-input.v1"
   :prf-transaction-ordering-change-identity-v1 "prf.transaction-ordering-change-identity.v1"
   :prf-transaction-ordering-v1 "prf.transaction-ordering.v1"
   :prf-transaction-ordering-v2 "prf.transaction-ordering.v2"
   :prf-transaction-ordering-v3 "prf.transaction-ordering.v3"
   :economic-publication-head-v1 "prf.economic-publication-head.v1"
   :prf-resubmission-validation-v1 "prf.resubmission-validation.v1"
   :prf-resubmission-reservation-v1 "prf.resubmission-reservation.v1"
   :prf-resubmission-finalization-v1 "prf.resubmission-finalization.v1"
   :prf-resubmission-admission-authorization-v2 "prf.resubmission-admission-authorization.v2"
   :prf-resubmission-admission-snapshot-v1 "prf.resubmission-admission-snapshot.v1"
   :prf-resubmission-admission-signing-v1 "prf.resubmission-admission-signing.v1"
   :related-claims-member "related-claims-member"
   :withdrawal-ledger-v1 "withdrawal-ledger.v1"
   :prf-protocol-genesis-v1 "PRF_PROTOCOL_GENESIS_V1"
   :prf-chain-instance-genesis-v1 "PRF_CHAIN_INSTANCE_GENESIS_V1"
   :prf-chain-configuration-v1 "PRF_CHAIN_CONFIGURATION_V1"
   :prf-chain-configuration-v2 "PRF_CHAIN_CONFIGURATION_V2"
   :prf-chain-configuration-v3 "PRF_CHAIN_CONFIGURATION_V3"
   :prf-chain-configuration-v4 "PRF_CHAIN_CONFIGURATION_V4"
   :authority-semantics-policy-v1 "AUTHORITY_SEMANTICS_POLICY_V1"
   :allocation-entitlement-policy-v1 "ALLOCATION_ENTITLEMENT_POLICY_V1"
   :prf-chain-configuration-transition-v1 "PRF_CHAIN_CONFIGURATION_TRANSITION_V1"
   :configuration-head-state-v1 "CONFIGURATION_HEAD_STATE_V1"
   :configuration-head-activation-v1 "CONFIGURATION_HEAD_ACTIVATION_V1"
   :configuration-transition-authorization-evidence-v1 "CONFIGURATION_TRANSITION_AUTHORIZATION_EVIDENCE_V1"
   :configuration-activation-lineage-v1 "CONFIGURATION_ACTIVATION_LINEAGE_V1"
   :authority-state-dependency-manifest-v1 "AUTHORITY_STATE_DEPENDENCY_MANIFEST_V1"
   :authority-state-snapshot-v1 "AUTHORITY_STATE_SNAPSHOT_V1"
   :governed-authority-result-receipt-v1 "GOVERNED_AUTHORITY_RESULT_RECEIPT_V1"
   :prf-chain-configuration-change-identity-v1 "prf.chain-configuration-change-identity.v1"
   :prf-risk-projection-v1 "prf.risk-projection.v1"
   :prf-risk-limit-policy-v1 "prf.risk-limit-policy.v1"
   :prf-risk-limit-evaluation-v1 "prf.risk-limit-evaluation.v1"
   :prf-verifier-registry-v1 "PRF_VERIFIER_REGISTRY_V1"
   :prf-verification-basis-v1 "PRF_VERIFICATION_BASIS_V1"
   :prf-verification-result-v1 "PRF_VERIFICATION_RESULT_V1"
   :prf-resubmission-chain-identity-v1 "prf.resubmission-chain-identity.v1"
   :prf-resubmission-chain-identity-v2 "prf.resubmission-chain-identity.v2"
   :prf-resubmission-chain-configuration-v1 "prf.resubmission-chain-configuration.v1"
   :prf-resubmission-chain-genesis-v1 "prf.resubmission-chain-genesis.v1"
   :prf-resubmission-chain-genesis-v2 "prf.resubmission-chain-genesis.v2"
   :prf-resubmission-chain-genesis-authorization-v1 "prf.resubmission-chain-genesis-authorization.v1"
   :programme-allocation-request-v1 "PROGRAMME_ALLOCATION_REQUEST_V1"
   :programme-plan-v1 "PROGRAMME_PLAN_V1"
   :programme-evidence-v1 "PROGRAMME_EVIDENCE_V1"
   :programme-receipt-v1 "PROGRAMME_RECEIPT_V1"
   :use-case-registry-v1 "USE_CASE_REGISTRY_V1"
   :use-case-definition-v1 "USE_CASE_DEFINITION_V1"
   :use-case-application-v1 "USE_CASE_APPLICATION_V1"
   :capability-invocation-binding-v1 "CAPABILITY_INVOCATION_BINDING_V1"
   :corpus-registry "corpus-registry"
   :reference-closure "reference-closure"
   :verification-profile "verification-profile"
   :custody-admission-decision-v1 "custody-admission-decision.v1"
   :semantic-composition-v1 "SEMANTIC_COMPOSITION_V1"
   :prf-resubmission-authority-context-v1 "prf.resubmission-authority-context.v1"
   :prf-resubmission-authoritative-checkpoint-v1 "prf.resubmission-authoritative-checkpoint.v1"
   :prf-resubmission-authoritative-disposition-v2 "prf.resubmission-authoritative-disposition.v2"
   :prf-yield-state-v1 "PRF_YIELD_STATE_V1"
   :prf-yield-effective-policy-v1 "PRF_YIELD_EFFECTIVE_POLICY_V1"
   :prf-yield-transition-event-v1 "PRF_YIELD_TRANSITION_EVENT_V1"
   :prf-yield-transition-basis-v1 "PRF_YIELD_TRANSITION_BASIS_V1"
   :prf-yield-withdrawal-ledger-state-cutpoint-v2 "PRF_YIELD_WITHDRAWAL_LEDGER_STATE_CUTPOINT_V2"})

;; The byte-level codec lives in the standalone canonical package. This namespace
;; remains the PRF compatibility facade for hashing and semantic projections.
(def out-of-domain! canonical-codec/out-of-domain!)
(defn validate-canonical-value! [v]
  (canonical-codec/validate-canonical-value! v))
(defn canonical-bytes [v]
  (canonical-codec/canonical-bytes v))
(defn canonical-bytes-hex [v]
  (canonical-codec/canonical-bytes-hex v))

;; Small byte/name helpers remain local because domain hashing and semantic
;; projection use them independently of the value encoder.
(defn- ba-concat [& bas]
  (let [total (reduce + (map count bas))
        out (byte-array total)]
    (loop [idx 0, bas bas]
      (when (seq bas)
        (let [ba (first bas)]
          (System/arraycopy ba 0 out idx (count ba))
          (recur (+ idx (count ba)) (rest bas)))))
    out))

(defn- keyword-string [k]
  (if-let [ns (namespace k)] (str ns "/" (name k)) (name k)))

(defn canonical-commitment
  "Build the portable canonical commitment fields for a content-addressed body
   that is hashed as sha256(domain-tag || canonical-bytes(body)):

     {:canonical/bytes <hex of canonical-bytes(body)>
      :canonical/hash <sha256:<hex> domain-separated hash>}

   Commitment format lineage: canonical-commitment v1
     → canonical-hash-scheme.v1
     → SHA-256 (sha256:<hex> reference form).
   This is deliberately a SHA-256 artifact format: when another hash scheme
   eventually exists it gets its own commitment format/version rather than
   silently reinterpreting the sha256: reference.

   A cross-language verifier recomputes
   sha256(domain-tag || hex-decode(:canonical/bytes)) == :canonical/hash and
   then checks that against the committed artifact hash — no Clojure-specific
   preimage (pr-str) is required."
  [domain-tag body]
  {:canonical/bytes (canonical-bytes-hex body)
   :canonical/hash (hash-ref/sha256-ref (domain-hash domain-tag body))})

(defn canonical-commitment-valid?
  "Verify a canonical commitment against the body it claims to commit: the
   committed :canonical/bytes must be canonical-bytes(body) and the committed
   :canonical/hash must equal sha256(domain-tag || canonical-bytes(body)).
   A commitment with neither field (legacy artifact) validates as true."
  [domain-tag body commitment]
  (let [cb (:canonical/bytes commitment)
        ch (:canonical/hash commitment)]
    (or (and (nil? cb) (nil? ch))
        (and (string? cb)
             (string? ch)
             (= cb (canonical-bytes-hex body))
             (= ch (hash-ref/sha256-ref (domain-hash domain-tag body)))))))

(defn project-committable-content
  "Project a value into canonical-safe form for content-addressing, byte-identical
   to the strict encoder's former coercions for representable runtime types:

     ratio             → {:canonical/type \"ratio\"
                           :canonical/numerator n :canonical/denominator d}
     double            → {:canonical/type \"float64\" :canonical/hex (exact)}
     float             → {:canonical/type \"float32\" :canonical/hex (exact)}
     BigDecimal        → {:canonical/type \"big-decimal\"
                           :canonical/value (.toPlainString x)}
     temporal value    → ISO-8601 string
     set               → sorted vector (canonical byte order)
     seq / map entry   → vector
     map / vector      → recursed

   All canonical values pass through unchanged, so existing commitments are
   unchanged; content that previously could not be hashed at all (ratios,
   doubles, floats, BigDecimal) becomes content-addressable.  Records remain
   rejected — convert them to plain maps explicitly."
  [v]
  (letfn [(walk [x]
            (cond
              (instance? clojure.lang.Ratio x)
              {:canonical/type "ratio"
               :canonical/numerator (numerator x)
               :canonical/denominator (denominator x)}
              (instance? Double x)
              {:canonical/type "float64" :canonical/hex (Double/toHexString x)}
              (instance? Float x)
              {:canonical/type "float32" :canonical/hex (Float/toHexString x)}
              (instance? java.math.BigDecimal x)
              {:canonical/type "big-decimal" :canonical/value (.toPlainString x)}
              (instance? java.time.temporal.TemporalAccessor x)
              (str x)
              (set? x) (vec (sort-by canonical-bytes-hex (map walk x)))
              (map? x) (into {} (map (fn [[k val]] [(walk k) (walk val)]) x))
              (vector? x) (mapv walk x)
              (sequential? x) (mapv walk x)
              :else x))]
    (walk v)))

(defn project-committable-content-for-intent
  "Intent-compatible arity wrapper for project-committable-content."
  [value _intent]
  (project-committable-content value))

;; ──────────────────────────────────────────────────────────────────────────────
;; Projection Helpers
;; ──────────────────────────────────────────────────────────────────────────────

(defn project-identity
  "Identity projection: pass through unchanged.
   Accepts optional intent arg (ignored) for hash-with-intent
   compatibility with the projection-fn calling convention."
  [x & _]
  x)

(defn project-self-hash-stripped
  "Cancel root-level self-hash keys (see self-hash-keys) and pass everything
   else through unchanged.  Used by intents that declare a self-hash exclusion
   but whose payload carries no other projection need.  Cancellation is
   root-level only; nested self-hash keys are ordinary content."
  [value _intent]
  (strip-self-hash-fields value))

(defn project-canonical-safe
  "Deep-project a value into canonical-safe form for canonical encoding: sets →
   sorted vectors (by string representation), maps and sequential values
   recursed, all other values passed through unchanged.

   This is the identity projection on canonical-safe values (nil, boolean,
   integer, string, keyword, vector, map), so existing commitments are
   byte-unchanged; set- and seq-bearing bodies that could not previously be
   hashed become content-addressable.  Map keys are preserved as-is.  Idempotent."
  [v]
  (cond
    (set? v) (vec (sort-by str v))
    (map? v) (into {} (map (fn [[k vv]] [k (project-canonical-safe vv)]) v))
    (sequential? v) (mapv project-canonical-safe v)
    :else v))

(defn project-canonical-safe-for-intent
  "Intent-compatible arity wrapper for canonical-safe projection."
  [value _intent]
  (project-canonical-safe value))

;; ──────────────────────────────────────────────────────────────────────────────
;; World State Projection
;; ──────────────────────────────────────────────────────────────────────────────
;;
;; Intent-aware semantic projection. This is NOT generic serialization.
;; It extracts identity-relevant structure from a simulation world state
;; for downstream claims, invariants, and projection-based allocation.
;;
;; Projection boundary rules:
;;   PRESERVE (identity-critical):
;;     - integers, strings, keywords, booleans
;;     - maps, vectors (structural identity)
;;   TRANSFORM (canonicalize only):
;;     - sets              → sorted vectors
;;     - java.time.Instant → ISO-8601 string
;;     - Double/Float      → {:type :float64 :value-str "..."}
;;     - Ratio             → {:type :ratio :value-str "..."}
;;   REPLACE (structure-only abstraction):
;;     - functions → {:type :fn}   (structured marker, not bare keyword)
;;
;; The result is a pure canonical value tree with the intent bound
;; explicitly: {:intent <kw> :structure <walked-world>}.

(defn project-world-to-structure-view
  "Project world state into a deterministic, canonical-safe structure view.

   This is a *semantic projection*, not serialization. It selects
   identity-relevant structure for downstream claims, invariants, and
   projection-based allocation systems.

   Validation order:
     runtime world → project-world-to-structure-view → validate-canonical-value!
     → domain-hash with :world-structure

   The projection function normalizes projectable runtime types BEFORE
   canonical validation. Type-category exclusions (:functions, :sets,
   :ratios, :instants, :doubles) are NOT in :intent/excludes because
   they are handled here, not rejected before projection. Only semantic
   exclusions (top-level key names) belong in :intent/excludes.

   Intent-aware: the intent keyword is bound into the output, making
   the projection lens explicit for hash-with-intent and evidence chain
   reproducibility.

   Projection boundary (what is preserved vs transformed vs replaced):
     Preserve — integers, strings, keywords, booleans, maps, vectors
     Transform — sets→sorted-vectors, Instant→ISO-string,
                 Float/Double→{:type :float64 :value-str \"%.17g\"}
                 Ratio→{:type :ratio :value-str \"%.17g\"}
     Replace  — functions→{:type :fn} (structured marker)

   When flattened-fields-atom is provided, records each flattening event
   as {:path [...], :type kw, :value raw, :contract kw} into the atom.
   This metadata is excluded from the returned structure so hashes remain
   stable; callers attach it externally as :projection/flattened-fields.

   Idempotent and fully deterministic across JVM invocations.
   Output passes validate-canonical-value! and is safe for canonical-bytes."
  [world intent & [flattened-fields-atom]]
  (letfn [(walk [x path]
            (cond
              ;; Primitives — pass through unchanged
              (nil? x) nil
              (boolean? x) x
              (integer? x) x
              (string? x) x
              (keyword? x) x
              ;; java.time.Instant → ISO-8601 string
              (instance? java.time.Instant x)
              (do (when flattened-fields-atom
                    (swap! flattened-fields-atom conj
                           {:path path
                            :type :instant
                            :value (.toString x)
                            :contract :instant→iso8601-string}))
                  (.toString x))
              ;; Double, Float → tagged representation (preserves type identity)
              (instance? Double x)
              (do (when flattened-fields-atom
                    (swap! flattened-fields-atom conj
                           {:path path
                            :type :float64
                            :value (double x)
                            :contract :float64-tagged-representation}))
                  {:type :float64 :value-str (format "%.17g" (double x))})
              (instance? Float x)
              (do (when flattened-fields-atom
                    (swap! flattened-fields-atom conj
                           {:path path
                            :type :float64
                            :value (float x)
                            :contract :float64-tagged-representation}))
                  {:type :float64 :value-str (format "%.17g" (float x))})
               ;; Ratio → exact tagged representation. Converting through double
               ;; would alias distinct rational values in a commitment.
              (instance? clojure.lang.Ratio x)
              (do (when flattened-fields-atom
                    (swap! flattened-fields-atom conj
                           {:path path
                            :type :ratio
                            :value (str (numerator x) "/" (denominator x))
                            :contract :ratio-tagged-representation}))
                  {:type :ratio
                   :value-str (format "%.17g" (double x))
                   :numerator (numerator x)
                   :denominator (denominator x)})
              ;; BigDecimal → tagged float64 representation
              (instance? java.math.BigDecimal x)
              (do (when flattened-fields-atom
                    (swap! flattened-fields-atom conj
                           {:path path
                            :type :float64
                            :value (.doubleValue x)
                            :contract :bigdecimal→float64-tagged-representation}))
                  {:type :float64 :value-str (format "%.17g" (.doubleValue x))})
              ;; Function → structured marker (NOT lossy :fn atom)
              (fn? x)
              (do (when flattened-fields-atom
                    (swap! flattened-fields-atom conj
                           {:path path
                            :type :function
                            :value (pr-str x)
                            :contract :function→fn-marker}))
                  {:type :fn})
              ;; Vector — recurse elements
              (vector? x) (mapv #(walk % (conj path [:vector %2])) x (range))
              ;; Map — recurse keys and values; ordering at encode time.
              ;; The strict encoder now encodes map keys as full canonical values,
              ;; so composite keys (structured ids) survive the projection as-is.
              (map? x)
              (persistent!
               (reduce-kv (fn [m k v]
                            (assoc! m
                                    (walk k (conj path [:key k]))
                                    (walk v (conj path [:value k]))))
                          (transient {}) x))
              ;; Set → sorted deterministic vector
              (set? x) (do (when flattened-fields-atom
                             (swap! flattened-fields-atom conj
                                    {:path path
                                     :type :set
                                     :value (vec (sort (map str x)))
                                     :contract :set→sorted-vector}))
                           (vec (sort (map #(walk % (conj path [:set %2])) x (range)))))
              ;; List, LazySeq, etc. → vector for canonical encoding compliance
              (sequential? x)
              (do (when flattened-fields-atom
                    (swap! flattened-fields-atom conj
                           {:path path
                            :type :sequential
                            :value (vec x)
                            :contract :sequential→vector}))
                  (mapv #(walk % (conj path [:sequential %2])) x (range)))
              :else
              (throw (ex-info
                      "Cannot project unsupported type to structure view"
                      {:type (type x) :value x}))))]
    {:intent intent
     :structure (walk world [])
     :projection/flattened-fields (when flattened-fields-atom (vec @flattened-fields-atom))}))

;; ──────────────────────────────────────────────────────────────────────────────
;; Hashing
;; ──────────────────────────────────────────────────────────────────────────────

(defn utf8-bytes
  "Encode a string as UTF-8 bytes."
  [s]
  (.getBytes s "UTF-8"))

(defn hex->bytes
  "Decode a hex string (with or without 0x prefix) into a byte array."
  [s]
  (let [hex (if (str/starts-with? s "0x") (subs s 2) s)
        n (count hex)
        result (byte-array (/ n 2))]
    (loop [i 0]
      (when (< i n)
        (aset result
              (int (/ i 2))
              (unchecked-byte
               (Integer/parseInt (subs hex i (+ i 2)) 16)))
        (recur (+ i 2))))
    result))

(defn hex->int
  "Decode a hex string (with or without 0x prefix) into a BigInteger."
  [s]
  (let [hex (if (str/starts-with? s "0x") (subs s 2) s)]
    (new BigInteger hex 16)))

(defn encode-uint256-be
  "Encode a non-negative integer as exactly 32 bytes, big-endian, left-padded."
  [n]
  (let [bi (if (instance? BigInteger n) n (BigInteger/valueOf (long n)))
        src (.toByteArray bi)
        buf (byte-array 32)
        src-len (count src)
        copy-len (min 32 src-len)
        src-pos (max 0 (- src-len 32))
        dst-pos (- 32 copy-len)]
    (System/arraycopy src src-pos buf dst-pos copy-len)
    buf))

(defn concat-byte-arrays
  "Concatenate a sequence of byte arrays into a single byte array."
  [seqs]
  (let [arrays (filter some? seqs)
        total (reduce + (map #(alength ^bytes %) arrays))
        result (byte-array total)
        pos (atom 0)]
    (doseq [^bytes arr arrays]
      (System/arraycopy arr 0 result @pos (alength arr))
      (swap! pos + (alength arr)))
    result))

(defn hash-bytes
  "Compute raw SHA-256 digest of a byte array.
   Returns a 32-byte byte-array for use in Merkle construction
   and domain-separated hashing."
  [^bytes ba]
  (let [digest (MessageDigest/getInstance "SHA-256")]
    (.update digest ba)
    (.digest digest)))

(defn bytes->hex
  "Convert a byte array to a lowercase hex string."
  [^bytes ba]
  (let [sb (StringBuilder.)]
    (doseq [b ba]
      (.append sb (format "%02x" (bit-and (int b) 0xFF))))
    (.toString sb)))

;; ──────────────────────────────────────────────────────────────────────────────
;; Canonical Hash Schemes (explicit versioned pinning)
;; ──────────────────────────────────────────────────────────────────────────────

(def canonical-hash-schemes
  "Immutable protocol definition of canonical hash schemes.

   Each scheme version is bound PERMANENTLY to exactly one algorithm:
   version and algorithm are one identity, not freely combinable properties.
   \"Immutable\" is protocol-immutability, not JVM-immutability: a Var can
   technically be redefined, but changing a version's registered algorithm
   constitutes an incompatible protocol/specification violation — enforced
   in practice by validate-hash-scheme!, the mismatch regression tests, and
   the pinned-root conformance vectors.

   The v1 descriptor needs only :algorithm because SHA-256 is fully
   parameter-free. A future scheme whose algorithm requires parameters
   (e.g. Poseidon field/width/rate/encoding) would declare them inside its
   own version's descriptor map; the registry schema grows ADDITIVELY when
   an actual second scheme exists and is deliberately not designed now.
   Adding a scheme also requires an explicit digest implementation branch in
   hash-bytes-with-scheme, tests, and its own commitment format; it must
   never redefine or rebind an existing entry."
  {"canonical-hash-scheme.v1" {:algorithm :sha256}})

(defn validate-hash-scheme!
  "Fail closed unless the scheme declares a non-empty string :scheme-version
   whose value is registered in canonical-hash-schemes AND whose :algorithm is
   EXACTLY the algorithm bound to that version. Version and algorithm are
   inseparable: this never accepts 'some supported algorithm' under any
   version. Returns the scheme unchanged when valid; throws otherwise."
  [scheme]
  (let [version (:scheme-version scheme)]
    (when-not (and (string? version) (seq version))
      (throw (ex-info "Invalid canonical hash scheme: :scheme-version must be a non-empty string"
                      {:type :invalid-hash-scheme
                       :scheme scheme})))
    (let [{bound :algorithm :as registered} (get canonical-hash-schemes version)
          declared (:algorithm scheme)]
      (when-not registered
        (throw (ex-info "Unregistered canonical hash scheme version"
                        {:type :unregistered-hash-scheme
                         :scheme-version version
                         :known (vec (keys canonical-hash-schemes))})))
      (when-not (= declared bound)
        (throw (ex-info "Canonical hash scheme does not match its registered algorithm binding"
                        {:type :hash-scheme-algorithm-mismatch
                         :scheme-version version
                         :declared-algorithm declared
                         :registered-algorithm bound})))))
  scheme)

(defn resolve-canonical-hash-scheme
  "Resolve a registered scheme version to its immutable scheme map
   {:scheme-version <v> :algorithm <a>}. Fails closed on unregistered versions."
  [scheme-version]
  (validate-hash-scheme!
   {:scheme-version scheme-version
    :algorithm (:algorithm (get canonical-hash-schemes scheme-version))}))

(def canonical-hash-scheme-v1
  "The immutable v1 canonical hash scheme: SHA-256.

   Every existing CANONICAL_HASH_SPEC_V1 root commits under exactly this
   scheme. Protocol-immutable forever: repointing this binding at another
   algorithm would be an incompatible specification violation, not a valid
   evolution step (a future scheme is a new versioned entry with its own
   commitment format). Old identities remain verifiable under this value."
  (resolve-canonical-hash-scheme "canonical-hash-scheme.v1"))

(defn hash-bytes-with-scheme
  "Digest raw bytes under an explicitly validated canonical hash scheme.

   Deliberately single-branch: only :sha256 has an implementation. The system
   is structurally algorithm-definable but operationally SHA-256-only; adding
   an algorithm later requires an explicit implementation branch here plus a
   new registered scheme version and tests — extending a supported-set alone
   changes nothing."
  [scheme ^bytes ba]
  (validate-hash-scheme! scheme)
  (case (:algorithm scheme)
    :sha256 (hash-bytes ba)
    ;; Unreachable while validate-hash-scheme! only admits registered schemes;
    ;; kept fail-closed against future registry drift.
    (throw (ex-info "No digest implementation for canonical hash scheme"
                    {:type :no-digest-implementation
                     :scheme (:scheme-version scheme)
                     :algorithm (:algorithm scheme)}))))

(defn domain-hash-preimage-bytes
  "Return the exact bytes hashed by domain-hash: UTF-8 domain tag directly
   concatenated with canonical typed value bytes (no length frame)."
  [domain-tag v]
  (let [tag-str (if (instance? String domain-tag)
                  domain-tag
                  (or (domain-tags domain-tag)
                      (throw (ex-info "Unknown domain tag" {:domain-tag domain-tag}))))]
    (ba-concat (utf8-bytes tag-str) (canonical-bytes v))))

(defn domain-hash-digest
  "Return the raw SHA-256 digest bytes for a domain-separated value."
  [domain-tag v]
  (hash-bytes (domain-hash-preimage-bytes domain-tag v)))

(defn domain-hash-with-scheme
  "Compute a domain-separated hash under an explicit scheme.
   HASH = SCHEME(DOMAIN_TAG || CANONICAL_BYTES), where SCHEME is resolved via
   validate-hash-scheme! and dispatched by hash-bytes-with-scheme. Today the
   sole registered scheme (canonical-hash-scheme.v1) instantiates SCHEME as
   SHA-256. Returns a 64-character hex string."
  [scheme domain-tag v]
  (let [tag-str (if (instance? String domain-tag)
                  domain-tag
                  (or (domain-tags domain-tag)
                      (throw (ex-info "Unknown domain tag"
                                      {:domain-tag domain-tag
                                       :known (keys domain-tags)}))))
        tag-bytes (utf8-bytes tag-str)
        canon (canonical-bytes v)]
    (bytes->hex (hash-bytes-with-scheme scheme (ba-concat tag-bytes canon)))))

(defn domain-hash
  "Compute a domain-separated canonical hash under the immutable v1 scheme.
   HASH = SHA256(DOMAIN_TAG || CANONICAL_BYTES)
   where DOMAIN_TAG is the UTF-8 encoding of the domain tag string.
   Returns a 64-char hex string.
   domain-tag should be a keyword from domain-tags, or a string.
   Stable v1 convenience for domain-hash-with-scheme/canonical-hash-scheme-v1."
  ([v]
   (domain-hash :evidence-record v))
  ([domain-tag v]
   (domain-hash-with-scheme canonical-hash-scheme-v1 domain-tag v)))

;; ──────────────────────────────────────────────────────────────────────────────
;; Evidence Content Projection (for JSON-round-trippable hashes)
;; ──────────────────────────────────────────────────────────────────────────────

(defn- project-for-content-hash
  "Project an evidence record into a form suitable for content-addressed
   hashing that survives JSON serialization/deserialization.
   Keywords are converted to strings (matching JSON behavior) and
   maps are sorted for deterministic ordering.
   Accepts optional intent arg (ignored) and optional flattened-fields-atom."
  [data & args]
  (let [[_ flattened-fields-atom] args
        _intent (first args)]
    (letfn [(walk [v path]
              (cond
                (instance? clojure.lang.Keyword v)
                (do (when flattened-fields-atom
                      (swap! flattened-fields-atom conj
                             {:path path
                              :type :keyword
                              :value (keyword-string v)
                              :contract :keyword→string}))
                    (keyword-string v))
                (ratio? v)
                (do (when flattened-fields-atom
                      (swap! flattened-fields-atom conj
                             {:path path
                              :type :ratio
                              :value (str (numerator v) "/" (denominator v))
                              :contract :ratio→tagged-map}))
                    {"$type" "ratio"
                     "$numerator" (numerator v)
                     "$denominator" (denominator v)})
                (instance? Double v)
                (do (when flattened-fields-atom
                      (swap! flattened-fields-atom conj
                             {:path path
                              :type :float64
                              :value (double v)
                              :contract :double→tagged-hex}))
                    {"$type" "float64"
                     "$hex" (Double/toHexString v)})
                (instance? Float v)
                (do (when flattened-fields-atom
                      (swap! flattened-fields-atom conj
                             {:path path
                              :type :float32
                              :value (float v)
                              :contract :float→tagged-hex}))
                    {"$type" "float32"
                     "$hex" (Float/toHexString v)})
                (instance? clojure.lang.IPersistentMap v)
                (into (sorted-map) (map (fn [[k v]] [(walk k (conj path [:key k])) (walk v (conj path [:value k]))]) v))
                (instance? clojure.lang.IPersistentVector v)
                (mapv (fn [x i] (walk x (conj path [:vector i]))) v (range))
                (sequential? v)
                (mapv (fn [x i] (walk x (conj path [:sequential i]))) v (range))
                :else v))]
      (walk data []))))

;; ──────────────────────────────────────────────────────────────────────────────
;; Read string with canonical hashing and flattening provenance
;; ──────────────────────────────────────────────────────────────────────────────

(defn read-string
  "Read an EDN string and produce a canonical hash with flattening provenance.

    Returns {:value parsed-value
             :hash hex-string
             :projection/flattened-fields [<flattening-events>]}.

    The :projection/flattened-fields metadata records every type transformation
    performed during the :evidence-content projection (keyword→string,
    ratio→tagged-map, double→tagged-hex, float→tagged-hex). This enables
    cross-language canonical hashing verification via check-projection-diff.

    Usage:
      (hc/read-string \"{:id 1 :name \\\"test\\\"}\")"
  [s]
  (let [value (edn/read-string s)
        flattened-fields (atom [])
        projected (project-for-content-hash value flattened-fields)
        hash-hex (domain-hash :evidence-content projected)]
    {:value value
     :hash hash-hex
     :projection/flattened-fields (vec @flattened-fields)}))

;; ──────────────────────────────────────────────────────────────────────────────
;; Intent Registry Contract
;; ──────────────────────────────────────────────────────────────────────────────
;;
;; Each intent is a machine-readable contract that explicitly declares:
;;   :intent/description — what kind of data this hash represents
;;   :intent/includes    — what data categories are intentionally covered
;;   :intent/excludes    — what data categories are explicitly excluded
;;   :intent/projection-fn — projection function applied before hashing
;;   :intent/domain-tag  — domain tag string for domain-separated hashing
;;   :intent/version     — monotonic integer; projection changes require increment
;;
;; This eliminates semantic drift between intents, provides explicit
;; machine-readable boundaries, and enables future linting support
;; (e.g., check that data being hashed matches declared scope).

(def ^:private self-hash-keys
  "Keys that hold the hash of the artifact currently being hashed.

   These keys are cancelled (stripped) before canonical hashing so an artifact
   does not recursively commit to its own attached hash.  Cancellation is a
   ROOT-LEVEL contract: only a self-hash key at the top level of the hashed
   value is stripped; a nested occurrence is ordinary content and is preserved.

   Do not add reference hashes here. A reference hash commits to another
   artifact or contextual component and is part of the current artifact's
   identity.  In particular, the bare :hash key is NOT listed: :hash is
   context-dependent and must be excluded per-intent when it is a self-hash
   (see :action), per HASH_INTENT_REGISTRY_SPEC_V1 §2.6.

   Examples:
   - self hash:      :node-hash on an evidence node
   - self hash:      :projection-hash on a projection artifact
   - reference hash: :action-hash on an evidence record
   - reference hash: :before-hash / :after-hash on a transition record
   - reference hash: :action-hash inside an :action-at projection
   - reference hash: :prev-hash / :cursor/final-self-hash on an evidence chain

   Per HASH_INTENT_REGISTRY_SPEC_V1 §2.6: only self-hashes are stripped.
   Reference hashes are part of the canonical content because they commit
   the artifact to other artifacts, actions, worlds, claims, attestations,
   registries, or execution contexts."
  #{:canonical-hash
    :intent-hash
    :registry-hash
    :projection-hash
    :allocation-result-hash
    :self-hash
    :node-hash})

(defn- stable-symbol-name
  [x]
  (cond
    (symbol? x) (str x)
    (var? x) (str (.-sym ^clojure.lang.Var x))
    (fn? x) (or (some-> x meta :name str)
                (.getName (class x)))
    :else (str x)))

(defn- project-canonical-artifact-value
  "Project registry/spec artifacts into canonical-safe data.
   This is intentionally generic and additive: it preserves artifact structure
   while converting runtime-only values into stable representations."
  [value]
  (letfn [(walk [x]
            (cond
              (nil? x) nil
              (boolean? x) x
              (integer? x) x
              (string? x) x
              (keyword? x) x
              (symbol? x) {:type :symbol :value (stable-symbol-name x)}
              (instance? java.time.Instant x) (.toString x)
              (instance? Double x) {:type :float64 :value-str (format "%.17g" (double x))}
              (instance? Float x) {:type :float64 :value-str (format "%.17g" (float x))}
              (instance? clojure.lang.Ratio x) {:type :ratio :value-str (format "%.17g" (double x))}
              (fn? x) {:type :fn :name (stable-symbol-name x)}
              (var? x) {:type :var :value (stable-symbol-name x)}
              (vector? x) (mapv walk x)
              (map? x) (persistent!
                        (reduce-kv (fn [m k v]
                                     (assoc! m (walk k) (walk v)))
                                   (transient {})
                                   x))
              (set? x) (vec (sort-by pr-str (map walk x)))
              (sequential? x) (mapv walk x)
              :else (throw (ex-info "Cannot project unsupported artifact value"
                                    {:type (type x) :value x}))))]
    (walk value)))

(defn- strip-self-hash-fields
  [value]
  (if (map? value)
    (apply dissoc value self-hash-keys)
    value))

(defn- project-canonical-artifact
  [value intent]
  {:intent intent
   :artifact (project-canonical-artifact-value (strip-self-hash-fields value))})

(defn project-intent-dsl
  "Canonical projection for INTENT_DSL_SPEC_V1 intent objects."
  [value intent]
  (project-canonical-artifact value intent))

(defn project-intent-registry-entry
  "Canonical projection for a single registered intent entry."
  [value intent]
  (project-canonical-artifact value intent))

(defn project-intent-registry
  "Canonical projection for intent registry artifacts."
  [value intent]
  (project-canonical-artifact value intent))

(defn project-projection-definition
  "Canonical projection for PROJECTION_DEFINITION_REGISTRY_SPEC_V1 entries."
  [value intent]
  (project-canonical-artifact value intent))

(defn project-projection-definition-registry
  "Canonical projection for projection definition registries."
  [value intent]
  (project-canonical-artifact value intent))

(defn project-projection-artifact
  "Canonical projection for PROJECTION_ARTIFACT_SPEC_V1 artifacts."
  [value intent]
  (project-canonical-artifact value intent))

(defn project-pro-rata-allocation-result
  "Canonical projection for PRO_RATA_ALLOCATION_RESULT_V1 artifacts."
  [value intent]
  (project-canonical-artifact value intent))

(defn project-priority-order
  "Canonical projection for PRIORITY_ORDER_V1 artifacts.

   The priority-order body is already canonical-safe; this projection strips
   the self envelope (:artifact/preimage / :artifact/content-hash) and wraps
   the body with the intent so the content hash is domain-separated."
  [value intent]
  (project-canonical-artifact value intent))

(defn- normalize-depends-on
  "Normalize :depends-on to canonical-safe format.
   - Enriched format (maps with :claim-id): extract sorted keyword IDs.
   - Legacy format (keyword vector): pass through as-is.
   - Mixed or empty: handled gracefully."
  [deps]
  (if (and (sequential? deps) (every? map? deps))
    (mapv :claim-id (sort-by :claim-id deps))
    deps))

(defn- enrich-depends-on
  "Normalize :depends-on to enriched format with concept-hash.
   - Enriched format (maps with :claim-id): project claim-id + concept-hash sorted by claim-id.
   - Legacy format (keyword vector): wrap with nil concept-hash, sorted.
   - Returns nil if deps is nil or empty."
  [deps]
  (when (seq deps)
    (if (and (sequential? deps) (every? map? deps))
      (mapv (fn [d] {:claim-id (:claim-id d) :concept-hash (:concept-hash d)})
            (sort-by :claim-id deps))
      (mapv (fn [id] {:claim-id id :concept-hash nil})
            (sort deps)))))

(defn project-claim-definition
  "Canonical projection for CLAIM_DEFINITION_REGISTRY_SPEC_V1 entries.
   Includes only the fields that define claim identity:
     :id, :version, :category, :inputs, :evaluation, :outputs
   Optionally includes :depends-on if present in the source value.
   When :depends-on uses enriched format ({:claim-id <kw> :concept-hash <hex> ...}),
   normalizes to keyword IDs only for backward-compatible structural hashing.
   Excludes :canonical-hash, runtime state, cached values, and generated metadata.
   Non-canonical types (symbols, vars, fns) are projected to canonical-safe
   representations via project-canonical-artifact-value."
  [value intent]
  (let [keep-keys [:id :version :category :inputs :evaluation :outputs]
        artifact (select-keys value keep-keys)
        artifact (if (contains? value :depends-on)
                   (assoc artifact :depends-on (normalize-depends-on (:depends-on value)))
                   artifact)
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-claim-definition-conceptual
  "Canonical projection for CONCEPT_CLAIM_DEFINITION_V1 entries.
   Projects :depends-on with resolved concept-hashes for transitive
   concept-aware hashing. When :depends-on contains enriched maps
   ({:claim-id <kw> :concept-hash <hex>}), projects the full maps sorted
   by claim-id. Falls back to wrapping legacy keyword IDs with nil
   concept-hash for backward compatibility."
  [value intent]
  (let [keep-keys [:id :version :category :inputs :evaluation :outputs]
        artifact (select-keys value keep-keys)
        artifact (if (contains? value :depends-on)
                   (assoc artifact :depends-on (enrich-depends-on (:depends-on value)))
                   artifact)
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-attestor
  "Canonical projection for ATTESTOR_REGISTRY_SPEC_V1 attestor entries.
   Purpose: hash the stable attestor identity and verification surface only.
   Includes exactly:
     :id, :type, :status, :verification, :delegates, :key-history
   Excludes self-hash fields, display/metadata fields, transient runtime state,
   and cached verification data.
   Missing :delegates or :key-history are normalized to empty vectors so the
   projection shape remains explicit and deterministic."
  [value intent]
  (let [artifact {:id (:id value)
                  :type (:type value)
                  :status (:status value)
                  :verification (:verification value)
                  :delegates (vec (or (:delegates value) []))
                  :key-history (vec (or (:key-history value) []))}
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-creation-provenance
  "Canonical projection for a standalone creation-provenance commitment.

    Creation provenance is excluded from the evidence-node identity projection
    (not in project-evidence-node's select-keys) but is authenticated through
    the canonical-integrity envelope via creation_provenance_hash. This
    projection produces that commitment."
  [value intent]
  (let [artifact {:creation/provenance (:creation/provenance value)}
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-source-creation
  "Canonical projection for a standalone source-creation provenance commitment.

    Source creation provenance is excluded from the evidence-node identity
    projection (not in project-evidence-node's select-keys) but is
    authenticated through the canonical-integrity envelope via
    source_creation_hash. This projection produces that commitment."
  [value intent]
  (let [artifact {:source/creation (:source/creation value)}
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-evidence-node
  "Canonical projection for execution evidence nodes.
   Includes only integrity-relevant execution provenance and evidence hashes.
   Excludes node self-identifiers, timestamps, and policy-filtered visible output
   so metadata-only or presentation-only changes do not alter node identity."
  [value intent]
  (let [artifact {:schema-version (:schema-version value)
                  :parent-hashes (vec (or (:parent-hashes value) []))
                  :bootstrap-roots (vec (or (:bootstrap-roots value) []))
                  :execution (select-keys (:execution value)
                                          [:execution-id :execution-kind :runner
                                           :registry-hash :policy-id :policy-hash])
                  :result {:status (get-in value [:result :status])
                           :summary (get-in value [:result :summary])}
                  :evidence (select-keys (:evidence value)
                                         [:inputs-hash :outputs-hash])
                  :attestations (vec (or (:attestations value) []))
                  :extensions (or (:extensions value) {})}
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-claim-result
  "Canonical projection for CLAIM_RESULT_SPEC_V1 claim evaluation results.
   Includes only the fields that define claim result identity:
     :claim-id, :claim-definition-hash, :holds?, :status
   Excludes :violations (transient diagnostic detail), :evidence-references
   (runtime addressing), and :depends-on (dependency graph)."
  [value intent]
  (let [artifact {:claim-id (:claim-id value)
                  :claim-definition-hash (:claim-definition-hash value)
                  :holds? (boolean (:holds? value))
                  :status (:status value)}
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-attestation
  "Canonical projection for ATTESTATION_SPEC_V1 attestation records.
   Includes only the fields that define attestation identity:
     :attestation-id, :attestor, :subject, :claim, :timestamp
   Excludes :signature (cryptographic proof, not identity) and
   :metadata (ephemeral)."
  [value intent]
  (let [artifact (select-keys value [:attestation-id :attestor :subject :claim :timestamp])
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-attestation-record
  "Canonical projection for ATTESTATION_RECORD_V1 attestation records.
   Includes the fields that define attestation identity:
     schema-version, subject-hash, subject-kind, claim-id, claim-result,
     attestor-id, signing-key-id, signed-at, provenance
   Excludes self-hash/id/signature/metadata (volatile or derived)."
  [value intent]
  (let [keep-keys [:schema-version
                   :attestation/subject-hash :attestation/subject-kind
                   :attestation/claim-id :attestation/claim-result
                   :attestation/attestor-id :attestation/signing-key-id
                   :attestation/signed-at :attestation/provenance]
        artifact (select-keys value keep-keys)
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-execution-definition
  "Canonical projection for EXECUTION_REGISTRY_SPEC_V1 execution definition entries.
   Includes only the fields that define execution identity:
     :id, :version, :kind, :runner, :entry, :execution/type, :execution/mode, :claims
   Excludes :description (documentation) and :depends-on (dependency graph)."
  [value intent]
  (let [keep-keys [:id :version :kind :runner :entry :execution/type :execution/mode :claims]
        artifact (select-keys value keep-keys)
        artifact (project-canonical-artifact-value artifact)]
    {:intent intent
     :artifact artifact}))

(defn project-action
  "Canonical projection for ACTION_V1 action records.
   Accepts a map (with :action/type or :type) or a simple value (string/keyword).
   - map: normalizes :type to :action/type, strips self-hashes
   - simple: wraps as {:action/type value}
   Requires :action/type to be present after normalization."
  [value intent]
  (let [value (cond
                (or (string? value) (keyword? value))
                {:action/type value}
                (and (map? value) (not (:action/type value)) (:type value))
                (-> (assoc value :action/type (:type value))
                    (dissoc :type))
                :else
                value)
        _ (when-not (:action/type value)
            (throw (ex-info "Action must have :action/type"
                            {:value value})))
        artifact (-> value
                     (dissoc :hash)   ; intent-specific: bare :hash is a self-hash on actions (§2.6)
                     strip-self-hash-fields
                     project-canonical-artifact-value)]
    {:intent intent
     :artifact artifact}))

(defn project-action-at
  "Canonical projection for ACTION_AT_V1 action occurrence records.
   Whitelist-only: includes exactly :action-hash, :step, and :block-time.
   Rejects unexpected keys and requires all three fields."
  [value intent]
  (let [allowed #{:action-hash :step :block-time}
        extra (remove allowed (keys value))]
    (when (seq extra)
      (throw (ex-info (str "Unexpected keys in action-at: " (pr-str extra))
                      {:extra extra :value value})))
    (when (or (nil? (:action-hash value))
              (nil? (:step value))
              (nil? (:block-time value)))
      (throw (ex-info "action-at requires :action-hash, :step, and :block-time"
                      {:value value})))
    (let [artifact (project-canonical-artifact-value
                    (select-keys value [:action-hash :step :block-time]))]
      {:intent intent
       :artifact artifact})))

(defn project-stability-snapshot
  "Project a stability snapshot for hash computation.
   Takes {:files {\"path\" \"content\" ...}} and sorts by path
   for deterministic hashing. Each value is canonicalized as a string."
  [value intent]
  (let [files (get value :files {})
        sorted (into (sorted-map) (map (fn [[k v]] [(str k) (str v)]) files))]
    {:intent intent
     :stability/files sorted}))

;; ──────────────────────────────────────────────────────────────────────────────
;; Bounty / with-bounty projections (single source of truth for hashing)
;; ──────────────────────────────────────────────────────────────────────────────
;; The with-bounty artifacts (bounty-payable.v1, bounty-payable-backing.v1,
;; and the ADR-0006 with-bounty composition artifacts) are content-addressed
;; through these projections.  The economics namespaces delegate their
;; domain-hash call sites here so intent-based hashing (hash-with-intent),
;; direct domain-hash, and committed artifact roots can never drift.

(def with-bounty-policy-defaults
  "Stage A defaults for a with-bounty policy (mirror of
   resolver-sim.economics.with-bounty.policy/default-policy)."
  {:composition/type :economics/with-bounty
   :composition/version 1
   :bounty/on-ineligible :skip
   :bounty/on-calculation-failure :abort-bounty
   :bounty/on-unsupported-effect :abort-before-mutation
   :bounty/failure-mode :base-independent})

(defn project-bounty-payable
  "Canonical projection of a bounty-payable.v1 artifact: the committed payable
   identity fields, projected canonical-safe."
  [value _intent]
  (project-canonical-safe
   (select-keys value
                [:schema-version
                 :payable/id
                 :payable/distribution-root
                 :payable/award-id
                 :payable/beneficiary
                 :payable/amount
                 :payable/kind
                 :payable/lifecycle
                 :payable/evidence-references
                 :payable/context])))

(defn project-bounty-payable-backing
  "Canonical projection of a bounty-payable-backing.v1 artifact: the committed
   backing identity fields, projected canonical-safe."
  [value _intent]
  (project-canonical-safe
   (select-keys value
                [:schema-version
                 :backing/id
                 :backing/payable-root
                 :backing/payable-id
                 :backing/distribution-root
                 :backing/amount
                 :backing/source-allocations
                 :backing/kind
                 :backing/lifecycle
                 :backing/context])))

(defn project-with-bounty-policy
  "Canonical projection of a with-bounty policy: the normalised policy (defaults
   filled in) so identical authored policies with omitted defaults hash
   identically.  Matches normalize-with-bounty-policy exactly."
  [value _intent]
  (merge with-bounty-policy-defaults (or value {})))

(defn project-with-bounty-obligation
  "Versioned projection of a with-bounty obligation identity:
     [:bounty-payable operation-root bounty-id recipient token amount policy-root]"
  [{:keys [operation-root bounty-id recipient token amount policy-root]} _intent]
  [:bounty-payable operation-root bounty-id recipient token amount policy-root])

(defn project-with-bounty-invocation
  "Versioned projection of a with-bounty step invocation identity:
     [policy-root step-id index capability-ref]"
  [value _intent]
  [(:policy-root value) (:step/id value) (:index value) (:capability/ref value)])

(defn project-with-bounty-effect
  "Canonical projection of a single with-bounty effect, projected canonical-safe."
  [value _intent]
  (project-canonical-safe value))

(defn project-with-bounty-effect-set
  "Canonical projection of a with-bounty effect set: the ordered effect roots
   bound under a (possibly nil) base plan root."
  [[base-plan-root effect-roots] _intent]
  [base-plan-root (vec effect-roots)])

(def with-bounty-plan-projection-fields
  "Committed fields of a with-bounty-application-plan.v1 identity."
  [:schema-version
   :plan/policy-root
   :plan/base-operation-root
   :plan/base-result-root
   :plan/base-plan-root
   :plan/extensions-resolution-root
   :plan/adapter
   :plan/effects
   :plan/effect-roots
   :plan/combined-effect-root
   :plan/effect-schema-roots
   :plan/declared-maximum
   :plan/funding-available
   :plan/obligation-id
   :plan/no-duplicate-creation-key
   :plan/preconditions
   :plan/idempotency-key
   :plan/context])

(defn project-with-bounty-application-plan
  "Canonical projection of a with-bounty-application-plan.v1: the committed plan
   fields, projected canonical-safe (sets → sorted vectors)."
  [value _intent]
  (project-canonical-safe (select-keys value with-bounty-plan-projection-fields)))

(def with-bounty-transition-evidence-fields
  "Committed fields of a with-bounty transition evidence identity."
  [:transition/type
   :plan/root
   :effect-root
   :combined-effect-root
   :world-before-root
   :world-after-root
   :payable/roots
   :backing/roots
   :custody/adjustment-roots
   :idempotent?
   :context])

(defn project-with-bounty-transition-evidence
  "Canonical projection of a with-bounty transition evidence record, projected
   canonical-safe."
  [value _intent]
  (project-canonical-safe (select-keys value with-bounty-transition-evidence-fields)))

(def with-bounty-verification-basis-fields
  "Committed fields of a with-bounty-verification-basis.v1 identity."
  [:schema-version
   :basis/subject-root
   :basis/package-root
   :basis/artifact-root
   :basis/verification-contract
   :basis/verification-contract-version
   :basis/entrypoint
   :basis/invocation-parameters
   :basis/dependency-lockfile-root
   :basis/runtime-root
   :basis/environment-root
   :basis/vector-set-root
   :basis/resource-limit-profile
   :basis/expected-public-result-schema
   :basis/classification-policy-root])

(defn project-with-bounty-verification-basis
  "Canonical projection of a with-bounty-verification-basis.v1 artifact, projected
   canonical-safe."
  [value _intent]
  (project-canonical-safe (select-keys value with-bounty-verification-basis-fields)))

(defn project-with-bounty-public-result
  "Canonical public-result projection of a with-bounty evaluation result.
   Excludes replay inputs, invocation evidence, and plan/effect payloads —
   only the committed public roots and the classification remain."
  [{:keys [status receipt]} _intent]
  {:status status
   :composition/policy-root (get-in receipt [:composition/policy-root])
   :composition/base-operation-root (get-in receipt [:composition/base-operation-root])
   :extensions/resolution-root (get-in receipt [:extensions/resolution-root])
   :bounty/obligation-id (get-in receipt [:bounty/obligation-id])
   :bounty/effect-root (get-in receipt [:bounty/effect-root])
   :bounty/application-plan-root (get-in receipt [:bounty/application-plan-root])})

;; ──────────────────────────────────────────────────────────────────────────────
;; PRF Genesis Projections
;; ──────────────────────────────────────────────────────────────────────────────
;;
;; protocol-genesis.v1 and chain-instance-genesis.v1 are canonical identity
;; artifacts (see resolver-sim.genesis). Their explicit versioned projections
;; select exactly the hash-bearing identity fields. Deployment/provenance
;; observations are rejected by the closed validator before hashing — they are
;; never silently dropped from the canonical preimage.

(def protocol-genesis-fields
  "Ordered identity fields of protocol-genesis.v1. The projection selects exactly
   these; the validator closes the top-level shape against any other key."
  [:genesis/schema
   :protocol/id
   :canonicalisation/root
   :semantics/root
   :governance/constitution-root
   :governance/evolution-policy-root
   :configuration/contract-root
   :evidence/contract-root
   :verification/contract-root
   :cross-domain/authority-policy-root])

(def chain-instance-genesis-control-plane-fields
  "Exactly-permitted keys of the :control-plane nested map of
   chain-instance-genesis.v1."
  [:address :runtime-code-keccak256])

(def chain-instance-genesis-governance-fields
  "Exactly-permitted keys of the :governance nested map of
   chain-instance-genesis.v1."
  [:authority-adapter :authority-adapter-code-keccak256
   :initial-authority-state-root])

(def chain-instance-genesis-fields
  "Ordered identity fields of chain-instance-genesis.v1 (top level)."
  [:genesis/schema
   :protocol/genesis-root
   :execution/chain-id
   :settlement/chain-id
   :control-plane
   :governance
   :configuration/initial-root])

(defn project-protocol-genesis
  "Canonical projection of protocol-genesis.v1: exactly the canonical identity
   fields, projected canonical-safe. Unknown keys never enter the preimage
   (they are rejected by the closed validator before hashing)."
  [value _intent]
  (project-canonical-safe (select-keys value protocol-genesis-fields)))

(defn project-chain-instance-genesis
  "Canonical projection of chain-instance-genesis.v1: exactly the canonical
   identity fields, projecting nested :control-plane and :governance to their
   exact sub-field sets. Unknown top-level or nested keys never enter the
   preimage."
  [value _intent]
  (let [cp (:control-plane value)
        gov (:governance value)
        base (select-keys value chain-instance-genesis-fields)]
    (project-canonical-safe
     (cond-> base
       (map? cp) (assoc :control-plane
                        (select-keys cp chain-instance-genesis-control-plane-fields))
       (map? gov) (assoc :governance
                         (select-keys gov chain-instance-genesis-governance-fields))))))

(def chain-configuration-fields
  "Ordered identity fields of chain-configuration.v1. All values are opaque
   sha256 reference roots to semantic sub-artefacts. The projection selects exactly
   these; the validator closes the shape against any other key."
  [:configuration/schema
   :module-registry/root
   :verifier-registry/root
   :evidence-policy/root
   :escrow-template-registry/root
   :parameter-policy/root
   :governance-policy/root
   :interoperability-policy/root])

(def chain-configuration-v2-fields
  "Ordered identity fields of chain-configuration.v2. V2 preserves every V1
   commitment and adds the exact semantics policy selected by configuration."
  (conj chain-configuration-fields :authority-semantics-policy/root))

(def chain-configuration-v3-fields
  "Ordered identity fields of chain-configuration.v3. V3 preserves every V2
   commitment and adds the exact allocation-entitlement policy selection."
  (conj chain-configuration-v2-fields :allocation-entitlement-policy/root))

(def chain-configuration-v4-fields
  "Ordered identity fields of chain-configuration.v4. V4 preserves every V3
   commitment and adds the exact authoritative risk-limit policy selection.
   The risk-limit policy root is MANDATORY in V4: a configuration without it
   is rejected, never silently treated as risk controls disabled."
  (conj chain-configuration-v3-fields :risk-limit-policy/root))

(def chain-configuration-transition-fields
  "Ordered identity fields of chain-configuration-transition.v1 (top level)."
  [:transition/schema
   :protocol/genesis-root
   :target
   :configuration/parent-root
   :configuration/new-root
   :verifier-registry/root
   :epoch])

(def chain-configuration-transition-target-fields
  "Exactly-permitted keys of the nested :target map of
   chain-configuration-transition.v1."
  [:target/type :target/root])

(defn project-chain-configuration
  "Canonical projection of chain-configuration.v1: exactly the canonical identity
   fields, projected canonical-safe. Unknown keys never enter the preimage."
  [value _intent]
  (project-canonical-safe (select-keys value chain-configuration-fields)))

(defn project-chain-configuration-v2
  "Canonical projection of chain-configuration.v2."
  [value _intent]
  (project-canonical-safe (select-keys value chain-configuration-v2-fields)))

(defn project-chain-configuration-v3
  "Canonical projection of chain-configuration.v3."
  [value _intent]
  (project-canonical-safe (select-keys value chain-configuration-v3-fields)))

(defn project-chain-configuration-v4
  "Canonical projection of chain-configuration.v4."
  [value _intent]
  (project-canonical-safe (select-keys value chain-configuration-v4-fields)))

(defn project-chain-configuration-transition
  "Canonical projection of chain-configuration-transition.v1: exactly the canonical
   identity fields, projecting nested :target to its exact sub-field set."
  [value _intent]
  (let [target (:target value)
        base (select-keys value chain-configuration-transition-fields)]
    (project-canonical-safe
     (cond-> base
       (map? target) (assoc :target
                            (select-keys target chain-configuration-transition-target-fields))))))

;; ──────────────────────────────────────────────────────────────────────────────
;; resubmission-chain-configuration.v1 & resubmission-chain-genesis.v1
;; ──────────────────────────────────────────────────────────────
;; Stage 1: canonical identity artifacts for the resubmission chain.
;; These mirror the protocol/chain-instance genesis pattern at the
;; resubmission layer: a configuration artifact (authority keys), a
;; chain-identity commitment basis, and a genesis artifact that declares
;; the family, initial configuration, and initial state root.

(def resubmission-chain-configuration-v1-fields
  "Ordered identity fields of the historical resubmission-chain-configuration.v1."
  [:configuration/schema
   :disposition-authority/public-key
   :receipt-authority/public-key])

(def resubmission-chain-configuration-v2-fields
  "Ordered identity fields of resubmission-chain-configuration.v2."
  [:configuration/schema
   :disposition-authority/public-key
   :receipt-authority/public-key
   :attempt-acceptance-definition/root])

(def resubmission-chain-configuration-v3-fields
  "Ordered identity fields of resubmission-chain-configuration.v3."
  [:configuration/schema
   :disposition-authority/public-key
   :receipt-authority/public-key
   :attempt-acceptance-definition/root
   :attempt-acceptance-authority-basis/root])

(def resubmission-chain-configuration-fields
  "Compatibility alias for the immutable V1 configuration field set."
  resubmission-chain-configuration-v1-fields)

(def resubmission-chain-identity-fields
  "The identity-relevant basis for deriving a resubmission chain-id.
   chain-id = sha256(domain-hash(prf.resubmission-chain-identity.v1, this-set)).
   Deliberately does NOT include the genesis root, so authority rotation
   (Stage 4) can change configuration without changing persistent chain identity."
  [:family/id
   :disposition-authority/public-key
   :receipt-authority/public-key])

(def resubmission-chain-genesis-fields
  "Ordered identity fields of resubmission-chain-genesis.v1 (top level)."
  [:genesis/schema :chain/id :family/id :configuration :initial-state/root])

(def resubmission-chain-identity-v2-fields
  "Ordered identity basis for deployment-scoped resubmission chain IDs."
  [:protocol-genesis/root
   :chain-instance-genesis/root
   :family/id
   :initial-configuration/root])

(def resubmission-chain-genesis-v2-fields
  "Ordered identity fields of resubmission-chain-genesis.v2 (top level)."
  [:genesis/schema
   :protocol-genesis/root
   :chain-instance-genesis/root
   :family/id
   :chain/id
   :configuration
   :configuration/root
   :initial-state/root])

(defn project-resubmission-chain-configuration
  "Canonical projection selected by configuration schema. V1 remains byte-for-
   byte compatible with its historical field set; V2 additionally commits the
   authorized attempt-acceptance-definition root."
  [value _intent]
  (let [fields (case (:configuration/schema value)
                 "resubmission-chain-configuration.v1"
                 resubmission-chain-configuration-v1-fields

                 "resubmission-chain-configuration.v2"
                 resubmission-chain-configuration-v2-fields

                 "resubmission-chain-configuration.v3"
                 resubmission-chain-configuration-v3-fields

                 [])]
    (project-canonical-safe (select-keys value fields))))

(defn project-resubmission-chain-identity
  "Canonical projection of the resubmission-chain-identity.v1 commitment basis:
   exactly family-id and authority keys, projected canonical-safe."
  [value _intent]
  (project-canonical-safe (select-keys value resubmission-chain-identity-fields)))

(defn project-resubmission-chain-genesis
  "Canonical projection of resubmission-chain-genesis.v1: exactly the canonical
   identity fields, projecting nested :configuration to its exact sub-field set.
   Unknown top-level or nested keys never enter the preimage."
  [value _intent]
  (let [base (select-keys value resubmission-chain-genesis-fields)
        cfg (:configuration base)]
    (project-canonical-safe
     (cond-> base
       (map? cfg) (assoc :configuration
                         (project-resubmission-chain-configuration cfg _intent))))))

(defn project-resubmission-chain-identity-v2
  "Canonical projection of the deployment-scoped resubmission chain identity
   basis. The initial configuration contributes only through its canonical root."
  [value _intent]
  (project-canonical-safe
   (select-keys value resubmission-chain-identity-v2-fields)))

(defn project-resubmission-chain-genesis-v2
  "Canonical projection of resubmission-chain-genesis.v2. V2 commits the
   protocol and chain-instance deployment roots plus the declared canonical
   configuration root; its embedded configuration retains the V1 projection."
  [value _intent]
  (let [base (select-keys value resubmission-chain-genesis-v2-fields)
        cfg (:configuration base)]
    (project-canonical-safe
     (cond-> base
       (map? cfg) (assoc :configuration
                         (project-resubmission-chain-configuration cfg _intent))))))

;; resubmission-chain-genesis-authorization.v1
;; ─────────────────────────────────────────────────────
;; Stage 3: thin authorization binding. Binds an exact genesis root to an
;; authenticated three-member authority decision. Does NOT duplicate genesis
;; content — that is transitively committed by the genesis root.

(def resubmission-chain-genesis-authorization-fields
  "Ordered identity fields of resubmission-chain-genesis-authorization.v1.
   A thin binding: genesis-root + authority fact references only.
   Does not duplicate family-id, chain-id, authority keys, or G0 — those
   are transitively committed by the genesis root."
  [:authorization/schema
   :authorization/genesis-root
   :authorization/force-authorisation-hash
   :authorization/authority-report-root])

(defn project-resubmission-chain-genesis-authorization
  "Canonical projection of resubmission-chain-genesis-authorization.v1: exactly
    the canonical identity fields, projected canonical-safe."
  [value _intent]
  (project-canonical-safe
   (select-keys value resubmission-chain-genesis-authorization-fields)))

;; ──────────────────────────────────────────────────────────────────────────────
;; resubmission-disposition-authority-context.v1 & authoritative-checkpoint.v1
;; ──────────────────────────────────────────────────────────────────────────────

(def resubmission-authority-context-fields
  "Identity fields of resubmission-disposition-authority-context.v1.
   The self-hash :authority/context-root is excluded from the projection
   (stripped before hashing). Permitted-actions are projected verbatim as a
   vector, preserving canonical order — duplicates are rejected by the
   closed validator before hashing."
  [:authority/context-schema
   :authority/genesis-root
   :authority/configuration-root
   :authority/authorization-root
   :authority/public-key
   :authority/epoch
   :authority/permitted-actions])

(defn project-resubmission-authority-context
  "Canonical projection of resubmission-disposition-authority-context.v1.
   Strips the self-hash :authority/context-root and selects exactly the
   identity fields, projected canonical-safe."
  [value _intent]
  (project-canonical-safe
   (select-keys value resubmission-authority-context-fields)))

(def resubmission-authoritative-checkpoint-fields
  "Identity fields of resubmission-authoritative-checkpoint.v1.
   The self-hash :checkpoint/root is excluded from the projection (stripped
   before hashing). :checkpoint/predecessor-root may be nil (initial checkpoint)."
  [:checkpoint/schema
   :checkpoint/chain-id
   :checkpoint/genesis-root
   :checkpoint/state-root
   :checkpoint/authority-context-root
   :checkpoint/configuration-root
   :checkpoint/epoch
   :checkpoint/authorization-mode
   :checkpoint/predecessor-root
   :checkpoint/sequence])

(defn project-resubmission-authoritative-checkpoint
  "Canonical projection of resubmission-authoritative-checkpoint.v1.
   Strips the self-hash :checkpoint/root and selects exactly the identity
   fields, projected canonical-safe."
  [value _intent]
  (project-canonical-safe
   (select-keys value resubmission-authoritative-checkpoint-fields)))

(def resubmission-authoritative-disposition-fields
  "Identity fields of resubmission-authoritative-disposition.v2.
   Includes :authority-context-root to bind the disposition to a specific
   authority context checkpoint. The signature is excluded from the hash
   preimage (stripped before signing/hashing)."
  [:attempt-disposition/schema
   :attempt-disposition/action
   :attempt-disposition/chain-id
   :attempt-disposition/genesis-root
   :attempt-disposition/configuration-root
   :attempt-disposition/authority-context-root
   :attempt-disposition/authority-epoch
   :attempt-disposition/parent-checkpoint-root
   :attempt-disposition/sequence
   :attempt-disposition/attempt-receipt-hash
   :attempt-disposition/previous-disposition-hash
   :attempt-disposition/status])

(defn project-resubmission-authoritative-disposition
  "Canonical projection of resubmission-authoritative-disposition.v2.
   Strips the signature and selects exactly the identity fields, projected
   canonical-safe."
  [value _intent]
  (project-canonical-safe
   (select-keys value resubmission-authoritative-disposition-fields)))

(def hash-intents
  "Map of hash intent keywords to their Intent Registry Contracts.
   Each contract explicitly declares the intent name, description,
   includes, exclusions, projection function, domain tag, and version.

   Usage: (hash-with-intent {:hash/intent :world-structure} data)

   Per INTENT_REGISTRY_SPEC_V1, each field is required."
  {:research-analysis-comparison-v1
   {:intent/name :research-analysis-comparison-v1
    :intent/domain-tag "RESEARCH_ANALYSIS_COMPARISON_V1"
    :intent/description "Canonical identity of a rooted coordinate-level research analysis comparison"
    :intent/includes #{:artifact/schema :research-definition/root :subject-roots
                       :case-axis/root :measure-axis/root :researcher-axis/root
                       :comparison/policy :comparison/inputs :comparison/output
                       :proof-of-possession/lineage}
    :intent/excludes #{:research-analysis-comparison/root :runtime-values :functions}
    :intent/projection-fn project-canonical-artifact
    :intent/version 1}

   :research-analysis-composition-v1
   {:intent/name :research-analysis-composition-v1
    :intent/domain-tag "RESEARCH_ANALYSIS_COMPOSITION_V1"
    :intent/description "Canonical identity of a deterministic derived research analysis composition"
    :intent/includes #{:artifact/schema :research-definition/root :subject-roots
                       :case-axis/root :measure-axis/root :researcher-axis/root
                       :composition/operator :composition/policy
                       :composition/input-analysis-roots :composition/output
                       :proof-of-possession/lineage
                       :research-analysis/general-ic-proven?}
    :intent/excludes #{:research-analysis-composition/root :runtime-values :functions}
    :intent/projection-fn project-canonical-artifact
    :intent/version 1}

   :appeal-bond-semantic-state
   {:intent/name :appeal-bond-semantic-state
    :intent/domain-tag "APPEAL_BOND_SEMANTIC_STATE_V1"
    :intent/description "Canonical semantic state of validated ordinary appeal bonds for transition evidence"
    :intent/includes #{:projection/version :appeal-bond/records
                       :appeal-bond/dispositions :appeal-bond/claims}
    :intent/excludes #{:aggregate-ledgers :scenario-metrics :runtime-values :functions}
    :intent/projection-fn project-committable-content-for-intent
    :intent/version 1}

   :replay-frame
   {:intent/name :replay-frame
    :intent/domain-tag "PRF_REPLAY_FRAME_V1"
    :intent/description "Canonical identity of an accepted sequential replay frame"
    :intent/includes #{:frame-index :state-roots :event-root :transition-root :basis-root :assurance :previous-frame-root}
    :intent/excludes #{:runtime-values :attempt-diagnostics}
    :intent/projection-fn project-identity
    :intent/version 1}

   :world-structure
   {:intent/name :world-structure
    :intent/domain-tag "WORLD_STATE_V1"
    :intent/description "Structural identity of system state for evidence anchoring"
    :intent/includes #{:domain-state :positions :balances :config :oracle-state :resolver-registry :bond-state :dispute-state :escrow-state :time-context}
    :intent/excludes #{:module-implementations :runtime-values}
    :intent/projection-fn project-world-to-structure-view
    :intent/version 1}

   :evidence-record
   {:intent/name :evidence-record
    :intent/domain-tag "EVIDENCE_RECORD_V1"
    :intent/description "Content identity of an individual evidence record"
    :intent/includes #{:attribution :action :result :context
                       :artifact-kind :temporal-context :sub-hashes}
    ;; :functions is a hard runtime-value rejection (defense-in-depth): evidence
    ;; records are finalized data and must not carry live runtime objects. This
    ;; complements (but does not replace) the writer-boundary rule that
    ;; finalized evidence schemas simply reject runtime values before they are
    ;; ever persisted.
    :intent/excludes #{:evidence-hash :timestamp :chain-metadata :functions}
    :intent/projection-fn project-identity
    :intent/version 1}

   :evidence-content
   {:intent/name :evidence-content
    :intent/domain-tag "EVIDENCE_CONTENT_V1"
    :intent/description "JSON-round-trippable content hash of an evidence record"
    :intent/includes #{:serialized-content :evidence-fields :artifact-body}
    ;; Keywords and hash-like keys are NOT excluded here: the projection
    ;; (project-for-content-hash) already normalizes them (keyword→string,
    ;; hash-keys preserved as content), so excluding them would reject
    ;; legitimate JSON-round-trippable evidence content. Only semantic
    ;; exclusions belong in :intent/excludes (see project-world-to-structure-view).
    :intent/excludes #{:chain-metadata :timestamps}
    :intent/projection-fn project-for-content-hash
    :intent/version 1}

   :evidence-chain
   {:intent/name :evidence-chain
    :intent/domain-tag "EVIDENCE_CHAIN_V1"
    :intent/description "Evidence chain linking structure for audit trails"
    :intent/includes #{:chain-links :registry-structure :prev-hash
                       :chain-seq :cursor/final-self-hash
                       :evidence/chain-self-hash}
    :intent/excludes #{:artifact-content :evidence-payload :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :evidence-chain-link-v1
   {:intent/name :evidence-chain-link-v1
    :intent/domain-tag "EVIDENCE_CHAIN_LINK_V1"
    :intent/description "Versioned evidence-chain link committing content, sequence, and predecessor"
    :intent/includes #{:evidence-hash :chain-seq :prev-hash :chain-hash-scheme}
    :intent/excludes #{:evidence-payload :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :run-evidence-hash-set-v1
   {:intent/name :run-evidence-hash-set-v1
    :intent/domain-tag "RUN_EVIDENCE_HASH_SET_V1"
    :intent/description "Canonical sorted-set commitment for a run's evidence content hashes"
    :intent/includes #{:evidence-hashes}
    :intent/excludes #{:artifact-order :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :evidence-hash-set
   {:intent/name :evidence-hash-set
    :intent/domain-tag "EVIDENCE_HASH_SET_V1"
    :intent/description "Schema-bearing canonical commitment to evidence hash identities"
    :intent/includes #{:schema-version :hash-algorithm :count :hashes}
    :intent/excludes #{:timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :evidence-finalization-v2
   {:intent/name :evidence-finalization-v2
    :intent/domain-tag "EVIDENCE_FINALIZATION_V2"
    :intent/description "Canonical payload identity for evidence-finalization.v2"
    :intent/includes #{:finalization-envelope}
    :intent/excludes #{:artifact-id :self-hash :signatures :timestamps}
    :intent/projection-fn project-self-hash-stripped
    :intent/version 2}

   :runner-finalization
   {:intent/name :runner-finalization
    :intent/domain-tag "RUNNER_FINALIZATION_V1"
    :intent/description "Immutable local runner identity and execution-result commitment"
    :intent/includes #{:runner-selection :runner-local :execution-result}
    :intent/excludes #{:artifact-path :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :run-package-index
   {:intent/name :run-package-index
    :intent/domain-tag "RUN_PACKAGE_INDEX_V1"
    :intent/description "Immutable references that define a runnable structured run package"
    :intent/includes #{:run-id :bundle-root-hash :artifacts}
    :intent/excludes #{:artifact-path :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :manifest
   {:intent/name :manifest
    :intent/domain-tag "MANIFEST_V1"
    :intent/description "Bundle manifest identity for artifact packaging"
    :intent/includes #{:manifest-metadata :bundle-structure :schema-version}
    :intent/excludes #{:content-payloads :individual-artifacts}
    :intent/projection-fn project-identity
    :intent/version 1}

   :protocol-state
   {:intent/name :protocol-state
    :intent/domain-tag "PROTOCOL_STATE_V1"
    :intent/description "Deterministic protocol-state snapshot for reproducibility"
    :intent/includes #{:force-authorisations :force-authorisations-consumed}
    :intent/excludes #{:world-state :traces :evidence-registry}
    :intent/projection-fn project-identity
    :intent/version 1}

   :reproducibility
   {:intent/name :reproducibility
    :intent/domain-tag "BENCHMARK_REPRODUCIBILITY_V1"
    :intent/description "Deterministic re-execution identity of a benchmark evidence bundle.
Authoritative projection is resolver-sim.benchmark.reproducibility/reproducibility-projection:
semantic benchmark content (manifest, results sans observational fields, metrics,
invariant summary, certification, commitment version, reproduce command), with all
runtime/materialization metadata removed (:environment, :repo, :run/manifest,
:timestamp, signature/post-hash fields, provenance). Two bundles with equal
reproducibility roots are claimed to be re-derivable from the same inputs under the
same execution semantics; wall-clock, host, VCS-dirt and signing differences do not
participate."
    :intent/includes #{:benchmark-metadata :results-semantics :metrics
                       :invariant-summary :benchmark-certification}
    :intent/excludes #{:environment :vcs-state :wall-clock :signatures
                       :materialization-locations :provenance-mode}
    :intent/projection-fn project-identity
    :intent/version 1}

   :bundle-root
   {:intent/name :bundle-root
    :intent/domain-tag "BUNDLE_ROOT_V1" :intent/description "Top-level benchmark bundle commitment. Authoritative projection is
resolver-sim.benchmark.integrity/hashable-evidence (field selection excluding :timestamp,
:evidence/hash, :evidence/signature, :evidence/public-key-path,
:benchmark/artifact-index, :repo, :run/manifest/:manifest/at
and :results/:scenario/artifacts), composed with project-world-to-structure-view (runtime-type
normalization). :evidence/commitment-version is deliberately NOT excluded: when present it is
committed into the hash, binding the bundle to its interpretation scheme. The
:intent/includes/:intent/excludes below are advisory semantic labels only; they
are NOT the field-level rule and the hash is not recomputed to match them.
:evidence/hash is the single stored commitment field; :bundle-root is this hash intent's
name (an alias)."
    :intent/includes #{:benchmark-metadata :environment :evidence-aggregates
                       :reproducibility :benchmark-certification :run/manifest}
    :intent/excludes #{:runtime-posthash-fields :operational-locations
                       :materialization-metadata :runtime-types}
    ;; Benchmark output contains exact ratios and runtime collections; normalize
    ;; them before canonical encoding rather than relying on lossy coercion.
    :intent/projection-fn project-world-to-structure-view
    :intent/version 2}

   :registry
   {:intent/name :registry
    :intent/domain-tag "REGISTRY_V1"
    :intent/description "Evidence registry commitment for artifact catalog"
    :intent/includes #{:registry-index :artifact-catalog :commitment-root}
    :intent/excludes #{:artifact-content :detailed-evidence :world-state}
    :intent/projection-fn project-identity
    :intent/version 1}

   :provenance
   {:intent/name :provenance
    :intent/domain-tag "PROVENANCE_V1"
    :intent/description "Provenance lineage and verification metadata"
    :intent/includes #{:provenance-lineage :verification-metadata :links}
    :intent/excludes #{:raw-evidence-content :world-snapshots}
    :intent/projection-fn project-identity
    :intent/version 1}

   :evm-projection
   {:intent/name :evm-projection
    :intent/domain-tag "EVM_PROJECTION_V1"
    :intent/description "EVM-compatible world subset for cross-system comparison"
    :intent/includes #{:comparable-world-subset :computed-invariants}
    :intent/excludes #{:sim-only-fields :module-implementations}
    :intent/projection-fn project-world-to-structure-view
    :intent/version 1}

   :state-diff
   {:intent/name :state-diff
    :intent/domain-tag "STATE_DIFF_V1"
    :intent/description "Structural diff state hash for trace comparisons"
    :intent/includes #{:diff-changes :path-stripped-values}
    :intent/excludes #{:before-values :after-values :raw-world-state}
    :intent/projection-fn project-identity
    :intent/version 1}

   :params-manifest
   {:intent/name :params-manifest
    :intent/domain-tag "PARAMS_MANIFEST_V1"
    :intent/description "Parameter manifest for multi-epoch reproducibility"
    :intent/includes #{:sim-params :config-params :run-params}
    :intent/excludes #{:runtime-state :evidence-data}
    :intent/projection-fn project-identity
    :intent/version 1}

   :invariant-attestation
   {:intent/name :invariant-attestation
    :intent/domain-tag "INVARIANT_ATTESTATION_V1"
    :intent/description "Per-step invariant attestation: which invariants held, which failed"
    :intent/includes #{:step :invariants :passed :failed :invariant-set-hash}
    :intent/excludes #{:full-world-state :action-detail :raw-trace}
    :intent/projection-fn project-identity
    :intent/version 1}

   :projection-evidence
   {:intent/name :projection-evidence
    :intent/domain-tag "PROJECTION_EVIDENCE_V1"
    :intent/description "Projection hash paired with world hash for cross-system comparison"
    :intent/includes #{:step :world-hash :projection-hash :projection-version}
    :intent/excludes #{:full-world-state :internal-fields}
    :intent/projection-fn project-identity
    :intent/version 1}

   :checkpoint-evidence
   {:intent/name :checkpoint-evidence
    :intent/domain-tag "CHECKPOINT_EVIDENCE_V1"
    :intent/description "Attestable checkpoint with world hash and chain position"
    :intent/includes #{:checkpoint-id :event-seq :world-hash :chain-head}
    :intent/excludes #{:full-world-state :trace-detail}
    :intent/projection-fn project-identity
    :intent/version 1}

   :scenario
   {:intent/name :scenario
    :intent/domain-tag "SCENARIO_V1"
    :intent/description "Stable content hash of a scenario definition for cross-runner scenario identification"
    :intent/includes #{:scenario-id :scenario-path :protocol :dispatcher-id :normalized-scenario}
    :intent/excludes #{:runtime-metadata :host-info :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :run-overview
   {:intent/name :run-overview
    :intent/domain-tag "RUN_OVERVIEW_V1"
    :intent/description "Normalized run overview for runner comparison and consensus"
    :intent/includes #{:overview-metadata :scenario-results :totals :suite-info}
    :intent/excludes #{:execution/raw :diagnostics :timestamps :absolute-paths :host-info}
    :intent/projection-fn project-committable-content-for-intent
    :intent/version 1}

   :benchmark-certification
   {:intent/name :benchmark-certification
    :intent/domain-tag "BENCHMARK_CERTIFICATION_V1"
    :intent/description "Benchmark run certification with invariant summary"
    :intent/includes #{:benchmark-id :scenario-count :all-invariants-pass
                       :final-state-hash :evidence-chain-root :invariant-summary}
    :intent/excludes #{:individual-results :detailed-evidence :traces}
    :intent/projection-fn project-identity
    :intent/version 1}

   :intent-dsl
   {:intent/name :intent-dsl
    :intent/domain-tag "INTENT_DSL_V1"
    :intent/description "Canonical identity of an INTENT_DSL_SPEC_V1 intent object"
    :intent/includes #{:intent/type :intent/version :intent/purpose :intent/scope
                       :intent/inputs :intent/constraints :intent/output}
    :intent/excludes #{:runtime-values :functions}
    :intent/projection-fn project-intent-dsl
    :intent/version 1}

   :intent-registry-entry
   {:intent/name :intent-registry-entry
    :intent/domain-tag "INTENT_REGISTRY_ENTRY_V1"
    :intent/description "Canonical identity of one registered intent contract"
    :intent/includes #{:intent/name :intent/domain-tag :intent/description
                       :intent/includes :intent/excludes :intent/projection-fn
                       :intent/version}
    :intent/excludes #{:runtime-values}
    :intent/projection-fn project-intent-registry-entry
    :intent/version 1}

   :intent-registry
   {:intent/name :intent-registry
    :intent/domain-tag "INTENT_REGISTRY_V1"
    :intent/description "Canonical identity of an intent registry artifact"
    :intent/includes #{:registry-version :intent-definitions :intent-hashes}
    :intent/excludes #{:registry-hash :runtime-values}
    :intent/projection-fn project-intent-registry
    :intent/version 1}

   :projection-definition
   {:intent/name :projection-definition
    :intent/domain-tag "PROJECTION_DEFINITION_V1"
    :intent/description "Canonical identity of one projection definition"
    :intent/includes #{:id :version :projection-type :intent-types :intent-purposes
                       :source :include-paths :exclude-paths :transforms
                       :output :claims :depends-on}
    :intent/excludes #{:canonical-hash :runtime-values :functions}
    :intent/projection-fn project-projection-definition
    :intent/version 1}

   :projection-definition-registry
   {:intent/name :projection-definition-registry
    :intent/domain-tag "PROJECTION_DEFINITION_REGISTRY_V1"
    :intent/description "Canonical identity of a projection definition registry artifact"
    :intent/includes #{:registry-version :projection-definitions :definition-hashes}
    :intent/excludes #{:registry-hash :runtime-values}
    :intent/projection-fn project-projection-definition-registry
    :intent/version 1}

   :projection-artifact
   {:intent/name :projection-artifact
    :intent/domain-tag "PROJECTION_ARTIFACT_V1"
    :intent/description "Canonical identity of a projection artifact excluding its self hash"
    :intent/includes #{:schema-version :projection-id :projection-type
                       :projection-version :intent :projection-definition-hash
                       :source :projection :claims}
    :intent/excludes #{:projection-hash :metadata :runtime-values}
    :intent/projection-fn project-projection-artifact
    :intent/version 1}

   :pro-rata-allocation-result
   {:intent/name :pro-rata-allocation-result
    :intent/domain-tag "PRO_RATA_ALLOCATION_RESULT_V1"
    :intent/description "Canonical identity of a pro-rata allocation result artifact excluding its self hash"
    :intent/includes #{:schema-version :artifact-kind :allocation-result-id
                       :allocation-result-type :allocation-result-version
                       :projection-artifact-hash :projection-definition-id
                       :projection-definition-hash :source :provenance
                       :allocation-result :shortfall-outcome :claims
                       :invariant-links}
    :intent/excludes #{:allocation-result-hash :metadata :external-refs :runtime-values}
    :intent/projection-fn project-pro-rata-allocation-result
    :intent/version 1}

   :pro-rata-allocation-policy
   {:intent/name :pro-rata-allocation-policy
    :intent/domain-tag "PRO_RATA_ALLOCATION_POLICY_V1"
    :intent/description "Canonical identity of the domain-neutral pro-rata mechanism and policy choices"
    :intent/includes #{:schema/version :mechanism/id :mechanism/version
                       :rounding-policy :tie-break-policy :redistribution-policy}
    :intent/excludes #{:runtime-values :functions}
    :intent/projection-fn (fn [value _] value)
    :intent/version 1}

   :pro-rata-policy-outcome
   {:intent/name :pro-rata-policy-outcome
    :intent/domain-tag "PRO_RATA_POLICY_OUTCOME_V1"
    :intent/description "Canonical consequence recording that a validated pro-rata result satisfied its derived policy"
    :intent/includes #{:schema/version :mechanism/id :mechanism/version
                       :request/root :policy/root :allocation-result/root
                       :outcome/status :rounding/outcome :violations}
    :intent/excludes #{:outcome/root :runtime-values :functions}
    :intent/projection-fn (fn [value _] value)
    :intent/version 1}

   :priority-order-v1
   {:intent/name :priority-order-v1
    :intent/domain-tag "PRIORITY_ORDER_V1"
    :intent/description "Canonical identity of a priority-order.v1 artifact body excluding its self content-addressing envelope"
    :intent/includes #{:artifact/kind :artifact/version :subjects
                       :subject-priority-keys :priority-classes :comparison-basis
                       :comparison-contract :tie-policy :unclassified-policy
                       :derivation :subject-set-root :comparison-basis-root
                       :priority-classes-root}
    :intent/excludes #{:artifact/content-hash :artifact/preimage :artifact/metadata
                       :metadata :runtime-values :functions}
    :intent/projection-fn project-priority-order
    :intent/version 1}

   :claim-definition
   {:intent/name :claim-definition
    :intent/domain-tag "CLAIM_DEFINITION"
    :intent/description "Canonical identity of one claim definition"
    :intent/includes #{:id :version :category :inputs
                       :evaluation :outputs :depends-on}
    :intent/excludes #{:canonical-hash :runtime-values :functions
                       :cached-values :generated-metadata :description}
    :intent/projection-fn project-claim-definition
    :intent/version 1}

   :claim-definition-conceptual
   {:intent/name :claim-definition-conceptual
    :intent/domain-tag "CONCEPT_CLAIM_DEFINITION_V1"
    :intent/description "Self-aware concept hash transitively including resolved dependency hashes"
    :intent/includes #{:id :version :category :inputs
                       :evaluation :outputs :depends-on}
    :intent/excludes #{:canonical-hash :concept-hash :runtime-values :functions
                       :cached-values :generated-metadata :description}
    :intent/projection-fn project-claim-definition-conceptual
    :intent/version 1}

   :attestor
   {:intent/name :attestor
    :intent/domain-tag "ATTESTOR"
    :intent/description "Canonical identity of one attestor registry entry"
    :intent/includes #{:id :type :status :verification :delegates :key-history}
    :intent/excludes #{:canonical-hash :attestor-hash :display-name :metadata
                       :runtime-values :cached-verification-data :private-keys}
    :intent/projection-fn project-attestor
    :intent/version 1}

   :evidence-node
   {:intent/name :evidence-node
    :intent/domain-tag "EVIDENCE_NODE_V1"
    :intent/description "Canonical identity of an execution evidence node"
    :intent/includes #{:schema-version :parent-hashes :bootstrap-roots
                       :execution :result :evidence :attestations :extensions}
    :intent/excludes #{:node-id :node-hash :timestamp :policy-output
                       :visible-failures :filtered-output :runtime-values}
    :intent/projection-fn project-evidence-node
    :intent/version 1}

   :creation-provenance
   {:intent/name :creation-provenance
    :intent/domain-tag "CREATION_PROVENANCE_V1"
    :intent/description "Domain-separated identity for a creation provenance commitment"
    :intent/includes #{:creation/provenance}
    :intent/excludes #{}
    :intent/projection-fn project-creation-provenance
    :intent/version 1}

   :source-creation
   {:intent/name :source-creation
    :intent/domain-tag "SOURCE_CREATION_V1"
    :intent/description "Domain-separated identity for a source creation provenance commitment"
    :intent/includes #{:source/creation}
    :intent/excludes #{}
    :intent/projection-fn project-source-creation
    :intent/version 1}

   :decision-evidence
   {:intent/name :decision-evidence
    :intent/domain-tag "DECISION_EVIDENCE_V1"
    :intent/description "Structured record of a decision with alternatives and selection"
    :intent/includes #{:decision-id :step :alternatives :selected :reasoning
                       :caller :workflow-id}
    :intent/excludes #{:full-world-state :trace-detail :internal-fields}
    :intent/projection-fn project-identity
    :intent/version 1}

   :invariant-failure
   {:intent/name :invariant-failure
    :intent/domain-tag "INVARIANT_FAILURE_V1"
    :intent/description "Evidence recorded when an invariant check fails and halts the simulation"
    :intent/includes #{:step :scenario-id :invariant-ids :details :halt-reason}
    :intent/excludes #{:full-world-state :raw-trace :internal-state}
    :intent/projection-fn project-identity
    :intent/version 1}

   :startup-validation
   {:intent/name :startup-validation
    :intent/domain-tag "STARTUP_VALIDATION_V1"
    :intent/description "Startup registry validation evidence — records that all semantic registries passed validation at system start"
    :intent/includes #{:registry-count :valid? :registry-summary :generated-at :schema-version}
    :intent/excludes #{:registry-detail :full-registry-data}
    :intent/projection-fn project-identity
    :intent/version 1}

   :claim-result
   {:intent/name :claim-result
    :intent/domain-tag "CLAIM_RESULT_V1"
    :intent/description "Canonical identity of a claim evaluation result"
    :intent/includes #{:claim-id :claim-definition-hash :holds? :status}
    :intent/excludes #{:violations :evidence-references :depends-on :metadata}
    :intent/projection-fn project-claim-result
    :intent/version 1}

   :attestation
   {:intent/name :attestation
    :intent/domain-tag "ATTESTATION_V1"
    :intent/description "Canonical identity of an attestation record"
    :intent/includes #{:attestation-id :attestor :subject :claim :timestamp}
    :intent/excludes #{:signature :metadata :canonical-hash}
    :intent/projection-fn project-attestation
    :intent/version 1}

   :attestation-record
   {:intent/name :attestation-record
    :intent/domain-tag "ATTESTATION_RECORD_V1"
    :intent/description "Canonical identity of a content-addressed attestation record, excluding self-hash and signature"
    :intent/includes #{:schema-version
                       :attestation/subject-hash :attestation/subject-kind
                       :attestation/claim-id :attestation/claim-result
                       :attestation/attestor-id :attestation/signing-key-id
                       :attestation/signed-at :attestation/provenance}
    :intent/excludes #{:attestation/id :attestation/hash :attestation/signature
                       :attestation/metadata :registry/indexed-at}
    :intent/projection-fn project-attestation-record
    :intent/version 1}

   :execution-definition
   {:intent/name :execution-definition
    :intent/domain-tag "EXECUTION_DEFINITION_V1"
    :intent/description "Canonical identity of an execution registry definition entry"
    :intent/includes #{:id :version :kind :runner :entry :execution/type :execution/mode :claims}
    :intent/excludes #{:description :depends-on :canonical-hash}
    :intent/projection-fn project-execution-definition
    :intent/version 1}

   :action
   {:intent/name :action
    :intent/domain-tag "ACTION_V1"
    :intent/description "Canonical identity of a normalized action payload. Includes normalized action content minus self-hash fields."
    :intent/includes #{:action/type :action/content}
    :intent/excludes #{:type :timestamp :metadata :trace :runtime-values
                       :canonical-hash :hash :node-hash}
    :intent/projection-fn project-action
    :intent/version 2}

   :action-at
   {:intent/name :action-at
    :intent/domain-tag "ACTION_AT_V1"
    :intent/description "Canonical identity of an action occurrence at a specific execution point."
    :intent/includes #{:action-hash :step :block-time}
    :intent/excludes #{:action :metadata :world-before :world-after :runtime-values}
    :intent/projection-fn project-action-at
    :intent/version 1}

   :stability/snapshot
   {:intent/name :stability/snapshot
    :intent/domain-tag "STABILITY_SNAPSHOT_V1"
    :intent/description "Canonical snapshot of source file contents for stability tracking.
                         Takes {:files {\"path\" \"content\" ...}} and produces a sorted,
                         deterministic hash. Used by STABILITY_MANIFEST.edn and
                         bb stability:check."
    :intent/includes #{:files :paths :contents}
    :intent/excludes #{:metadata :timestamps :runtime-state}
    :intent/projection-fn project-stability-snapshot
    :intent/version 1}

   :trust-sequence-definition
   {:intent/name :trust-sequence-definition
    :intent/domain-tag "TRUST_SEQUENCE_DEFINITION_V1"
    :intent/description "Canonical identity of a trust-sequence-definition artifact"
    :intent/includes #{:schema-version :id :provider :steps}
    :intent/excludes #{:root :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :procedure-execution-witness
   {:intent/name :procedure-execution-witness
    :intent/domain-tag "PROCEDURE_EXECUTION_WITNESS_V1"
    :intent/description "Canonical identity of a procedure-execution-witness artifact"
    :intent/includes #{:schema-version :id :definition-root :initial-input-root :steps :result-root}
    :intent/excludes #{:root :verification :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :pool-availability-v2
   {:intent/name :pool-availability-v2
    :intent/domain-tag "POOL_AVAILABILITY_V2"
    :intent/description "Canonical identity of a pool-availability v2 snapshot artifact, including predecessor binding"
    :intent/includes #{:artifact/type :pool/id :pool/kind :pool/owner-id
                       :pool/state-root :pool/policy-root
                       :pool/snapshot-time
                       :pool/gross-amount :pool/reserved-amount
                       :pool/protected-amount :pool/available-amount
                       :pool/liability-roots :pool/reservation-roots
                       :pool/predecessor-hash}
    :intent/excludes #{:artifact/hash :metadata}
    :intent/projection-fn project-identity
    :intent/version 1}

   :pool-reservation
   {:intent/name :pool-reservation
    :intent/domain-tag "POOL_RESERVATION_V1"
    :intent/description "Canonical identity of a pool reservation artifact"
    :intent/includes #{:artifact/type :reservation/id :reservation/pool-root
                       :reservation/amount :reservation/purpose-root}
    :intent/excludes #{:artifact/hash :metadata}
    :intent/projection-fn project-identity
    :intent/version 1}

   :award-calculation-v2
   {:intent/name :award-calculation-v2
    :intent/domain-tag "AWARD_CALCULATION_V2"
    :intent/description "Canonical identity of an award calculation v2 artifact, including eligibility binding roots"
    :intent/includes #{:artifact/type :award/id :award/policy-root
                       :award/pool-availability-root
                       :award/claim-set-root :award/evidence-set-root
                       :award/beneficiary-id :award/calculation-time
                       :award/amount :award/scale
                       :award/calculation-components
                       :award/eligibility-result
                       :award/eligibility-policy-root
                       :award/check-set-root
                       :award/mode}
    :intent/excludes #{:artifact/hash :metadata}
    :intent/projection-fn project-identity
    :intent/version 1}

   :check-set
   {:intent/name :check-set
    :intent/domain-tag "CHECK_SET_V1"
    :intent/description "Canonical root of a sorted, deduplicated set of eligibility check IDs"
    :intent/includes #{:check/ids}
    :intent/excludes #{:metadata}
    :intent/projection-fn project-identity
    :intent/version 1}

   :award-policy
   {:intent/name :award-policy
    :intent/domain-tag "AWARD_POLICY_V1"
    :intent/description "Canonical identity of an award policy artifact committing the required eligibility check-set root"
    :intent/includes #{:artifact/type :policy/id :policy/required-check-ids
                       :policy/check-set-root}
    :intent/excludes #{:artifact/hash :metadata}
    :intent/projection-fn project-identity
    :intent/version 1}

   :claim-set
   {:intent/name :claim-set
    :intent/domain-tag "CLAIM_SET_V1"
    :intent/description "Canonical root of a sorted, deduplicated set of claim hashes"
    :intent/includes #{:claim/roots}
    :intent/excludes #{:metadata}
    :intent/projection-fn project-identity
    :intent/version 1}

   :lab-parameter-root
   {:intent/name :lab-parameter-root
    :intent/domain-tag "LAB_PARAMETER_ROOT_V1"
    :intent/description "Canonical parameter-root of validated Assurance Lab inputs for a run"
    :intent/includes #{:inputs :parameters}
    :intent/excludes #{:runtime-values :functions :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :lab-withdrawal-fcfs
   {:intent/name :lab-withdrawal-fcfs
    :intent/domain-tag "LAB_WITHDRAWAL_FCFS_V1"
    :intent/description "Canonical witness binding of the Assurance Lab FCFS sequential-withdrawal outcome"
    :intent/includes #{:mechanism :available :requested-total :filled-total
                       :deferred-total :rows}
    :intent/excludes #{:runtime-values :functions :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :fail-action-policy
   {:intent/name :fail-action-policy
    :intent/domain-tag "FAIL_ACTION_POLICY_V1"
    :intent/description "Committed root of a declared pro-rata fail-action policy: how a partial-fill shortfall is treated per bucket (deferred/haircut) when the fill cannot be settled in full"
    :intent/includes #{:mode :deferred-policy :haircut-policy :treatment :priority}
    :intent/excludes #{:runtime-values :functions :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :bounty-payable-v1
   {:intent/name :bounty-payable-v1
    :intent/domain-tag "BOUNTY_PAYABLE_V1"
    :intent/description "Content-addressed root of a bounty-payable.v1 artifact: the committed payable identity"
    :intent/includes #{:schema-version :payable/id :payable/distribution-root
                       :payable/award-id :payable/beneficiary :payable/amount
                       :payable/kind :payable/lifecycle
                       :payable/evidence-references :payable/context}
    :intent/excludes #{:payable/hash :runtime-values :functions}
    :intent/projection-fn project-bounty-payable
    :intent/version 1}

   :bounty-payable-backing-v1
   {:intent/name :bounty-payable-backing-v1
    :intent/domain-tag "BOUNTY_PAYABLE_BACKING_V1"
    :intent/description "Content-addressed root of a bounty-payable-backing.v1 artifact: the committed backing identity"
    :intent/includes #{:schema-version :backing/id :backing/payable-root
                       :backing/payable-id :backing/distribution-root
                       :backing/amount :backing/source-allocations
                       :backing/kind :backing/lifecycle :backing/context}
    :intent/excludes #{:backing/hash :runtime-values :functions}
    :intent/projection-fn project-bounty-payable-backing
    :intent/version 1}

   :with-bounty-policy-v1
   {:intent/name :with-bounty-policy-v1
    :intent/domain-tag "WITH_BOUNTY_POLICY_V1"
    :intent/description "Content-addressed root of a normalised with-bounty policy: the declared contract of a with-bounty composition"
    :intent/includes #{:composition/type :composition/version
                       :bounty/on-ineligible :bounty/on-calculation-failure
                       :bounty/on-unsupported-effect :bounty/failure-mode
                       :base :bounty}
    :intent/excludes #{:policy/root :runtime-values :functions}
    :intent/projection-fn project-with-bounty-policy
    :intent/version 1}

   :with-bounty-invocation-v1
   {:intent/name :with-bounty-invocation-v1
    :intent/domain-tag "WITH_BOUNTY_INVOCATION_V1"
    :intent/description "Deterministic identity of one with-bounty step invocation (eligibility or amount)"
    :intent/includes #{:policy-root :step/id :index :capability/ref}
    :intent/excludes #{:runtime-values :functions :timestamps}
    :intent/projection-fn project-with-bounty-invocation
    :intent/version 1}

   :with-bounty-obligation-v1
   {:intent/name :with-bounty-obligation-v1
    :intent/domain-tag "WITH_BOUNTY_OBLIGATION_V1"
    :intent/description "Deterministic obligation identity of a with-bounty payable"
    :intent/includes #{:operation-root :bounty-id :recipient :token :amount :policy-root}
    :intent/excludes #{:runtime-values :functions :timestamps}
    :intent/projection-fn project-with-bounty-obligation
    :intent/version 1}

   :with-bounty-effect-v1
   {:intent/name :with-bounty-effect-v1
    :intent/domain-tag "WITH_BOUNTY_EFFECT_V1"
    :intent/description "Content-addressed root of a single validated with-bounty effect"
    :intent/includes #{:effect/contract :effect/kind :effect/params}
    :intent/excludes #{:effect/root :runtime-values :functions}
    :intent/projection-fn project-with-bounty-effect
    :intent/version 1}

   :with-bounty-effect-set-v1
   {:intent/name :with-bounty-effect-set-v1
    :intent/domain-tag "WITH_BOUNTY_EFFECT_SET_V1"
    :intent/description "Combined with-bounty effect-set root: base plan root plus the ordered effect roots"
    :intent/includes #{:base-plan-root :effect-roots}
    :intent/excludes #{:runtime-values :functions :timestamps}
    :intent/projection-fn project-with-bounty-effect-set
    :intent/version 1}

   :with-bounty-application-plan-v1
   {:intent/name :with-bounty-application-plan-v1
    :intent/domain-tag "WITH_BOUNTY_APPLICATION_PLAN_V1"
    :intent/description "Content-addressed root of a with-bounty application plan committing creation preconditions and the combined effect set"
    :intent/includes #{:schema-version :plan/policy-root :plan/base-operation-root
                       :plan/base-result-root :plan/base-plan-root
                       :plan/extensions-resolution-root :plan/adapter
                       :plan/effects :plan/effect-roots
                       :plan/combined-effect-root :plan/effect-schema-roots
                       :plan/declared-maximum :plan/funding-available
                       :plan/obligation-id :plan/no-duplicate-creation-key
                       :plan/preconditions :plan/idempotency-key :plan/context}
    :intent/excludes #{:plan/hash :runtime-values :functions}
    :intent/projection-fn project-with-bounty-application-plan
    :intent/version 1}

   :with-bounty-transition-evidence-v1
   {:intent/name :with-bounty-transition-evidence-v1
    :intent/domain-tag "WITH_BOUNTY_TRANSITION_EVIDENCE_V1"
    :intent/description "Content-addressed transition evidence binding a with-bounty application plan to the resulting protocol transition"
    :intent/includes #{:transition/type :plan/root :effect-root
                       :combined-effect-root :world-before-root
                       :world-after-root :payable/roots :backing/roots
                       :custody/adjustment-roots :idempotent? :context}
    :intent/excludes #{:transition/hash :runtime-values :functions}
    :intent/projection-fn project-with-bounty-transition-evidence
    :intent/version 1}

   :with-bounty-verification-basis-v1
   {:intent/name :with-bounty-verification-basis-v1
    :intent/domain-tag "WITH_BOUNTY_VERIFICATION_BASIS_V1"
    :intent/description "Content-addressed root of a with-bounty verification basis: exactly what a verifier evaluated"
    :intent/includes #{:schema-version :basis/subject-root :basis/package-root
                       :basis/artifact-root :basis/verification-contract
                       :basis/verification-contract-version :basis/entrypoint
                       :basis/invocation-parameters
                       :basis/dependency-lockfile-root :basis/runtime-root
                       :basis/environment-root :basis/vector-set-root
                       :basis/resource-limit-profile
                       :basis/expected-public-result-schema
                       :basis/classification-policy-root}
    :intent/excludes #{:basis/root :runtime-values :functions}
    :intent/projection-fn project-with-bounty-verification-basis
    :intent/version 1}

   :with-bounty-public-result-v1
   {:intent/name :with-bounty-public-result-v1
    :intent/domain-tag "WITH_BOUNTY_PUBLIC_RESULT_V1"
    :intent/description "Canonical public-result root of a with-bounty evaluation for verifier comparison"
    :intent/includes #{:status :composition/policy-root
                       :composition/base-operation-root
                       :extensions/resolution-root :bounty/obligation-id
                       :bounty/effect-root :bounty/application-plan-root}
    :intent/excludes #{:replay/inputs :invocation-evidence :diagnostics}
    :intent/projection-fn project-with-bounty-public-result
    :intent/version 1}

   :confidence-composition-v1
   {:intent/name :confidence-composition-v1
    :intent/domain-tag "CONFIDENCE_COMPOSITION_V1"
    :intent/description "Hash-bound consecutive concatenation of confidence components bound to a :purpose (canonical-value-sequence.v1 contract)"
    :intent/includes #{:encoding-contract :purpose :component-count :components}
    :intent/excludes #{:timestamps :runtime-values :functions}
    :intent/projection-fn project-identity
    :intent/version 1}

   :research-command-trace-v1
   {:intent/name :research-command-trace-v1
    :intent/domain-tag "RESEARCH_COMMAND_TRACE_V1"
    :intent/description "Legacy research-command trace root (v1, DEPRECATED — use research-command-trace-v2 / bound-sequence)"
    :intent/includes #{:command-id :commands}
    :intent/excludes #{:timestamps :runtime-values :functions}
    :intent/projection-fn project-identity
    :intent/version 1}

   :research-command-trace-v2
   {:intent/name :research-command-trace-v2
    :intent/domain-tag "RESEARCH_COMMAND_TRACE_V2"
    :intent/description "Research-command-trace.v2 root over a canonical-value-sequence.v1 commitment with an explicit :purpose"
    :intent/includes #{:trace/schema-version :trace/purpose :trace/component-count
                       :trace/components}
    :intent/excludes #{:trace/root :timestamps :runtime-values :functions}
    :intent/projection-fn project-identity
    :intent/version 1}

   :research-execution
   {:intent/name :research-execution
    :intent/domain-tag "RESEARCH_EXECUTION_V1"
    :intent/description "Exact researcher execution identity binding portable command, assignment, resolved composition, ordered trace, and outcome"
    :intent/includes #{:research-execution/command-root :research-execution/assignment-root
                       :research-execution/composition-root :research-execution/trace-root
                       :research-execution/outcome-root :research-execution/classification}
    :intent/excludes #{:research-execution/root :timestamps :runtime-values :functions}
    :intent/projection-fn project-identity
    :intent/version 1}

   :research-benchmark-pack
   {:intent/name :research-benchmark-pack
    :intent/domain-tag "RESEARCH_BENCHMARK_PACK_V1"
    :intent/description "Frozen exact research benchmark member plan with resolved extension composition"
    :intent/includes #{:research-pack/command-root :research-pack/assignment-root
                       :research-pack/plan-root :research-pack/members
                       :research-pack/composition-root :research-pack/resolution-root}
    :intent/excludes #{:research-pack/root :runtime-values :functions :timestamps}
    :intent/projection-fn project-identity
    :intent/version 1}

   :prf-protocol-genesis-v1
   {:intent/name :prf-protocol-genesis-v1
    :intent/domain-tag "PRF_PROTOCOL_GENESIS_V1"
    :intent/description "Canonical SHA-256 identity of a protocol-genesis.v1 constitutional protocol artifact"
    :intent/includes #{:genesis/schema :protocol/id :canonicalisation/root
                       :semantics/root :governance/constitution-root
                       :governance/evolution-policy-root :configuration/contract-root
                       :evidence/contract-root :verification/contract-root
                       :cross-domain/authority-policy-root}
    :intent/excludes #{:runtime-values :functions :deployment-metadata :timestamps}
    :intent/projection-fn project-protocol-genesis
    :intent/version 1}

   :prf-chain-instance-genesis-v1
   {:intent/name :prf-chain-instance-genesis-v1
    :intent/domain-tag "PRF_CHAIN_INSTANCE_GENESIS_V1"
    :intent/description "Canonical SHA-256 identity of a chain-instance-genesis.v1 execution instance"
    :intent/includes #{:genesis/schema :protocol/genesis-root :execution/chain-id
                       :settlement/chain-id :control-plane :governance
                       :configuration/initial-root}
    :intent/excludes #{:runtime-values :functions :deployment-metadata
                       :block-context :timestamps}
    :intent/projection-fn project-chain-instance-genesis
    :intent/version 1}

   :prf-chain-configuration-v1
   {:intent/name :prf-chain-configuration-v1
    :intent/domain-tag "PRF_CHAIN_CONFIGURATION_V1"
    :intent/description "Canonical SHA-256 identity of a chain-configuration.v1 semantic configuration state"
    :intent/includes #{:configuration/schema
                       :module-registry/root :verifier-registry/root
                       :evidence-policy/root :escrow-template-registry/root
                       :parameter-policy/root :governance-policy/root
                       :interoperability-policy/root}
    :intent/excludes #{:runtime-values :functions :deployment-metadata :timestamps}
    :intent/projection-fn project-chain-configuration
    :intent/version 1}

   :prf-chain-configuration-v3
   {:intent/name :prf-chain-configuration-v3
    :intent/domain-tag "PRF_CHAIN_CONFIGURATION_V3"
    :intent/description "Canonical SHA-256 identity of a chain-configuration.v3 semantic configuration state"
    :intent/includes #{:configuration/schema
                       :module-registry/root :verifier-registry/root
                       :evidence-policy/root :escrow-template-registry/root
                       :parameter-policy/root :governance-policy/root
                       :interoperability-policy/root
                       :authority-semantics-policy/root
                       :allocation-entitlement-policy/root}
    :intent/excludes #{:runtime-values :functions :deployment-metadata :timestamps}
    :intent/projection-fn project-chain-configuration-v3
    :intent/version 1}

   :prf-chain-configuration-v4
   {:intent/name :prf-chain-configuration-v4
    :intent/domain-tag "PRF_CHAIN_CONFIGURATION_V4"
    :intent/description "Canonical SHA-256 identity of a chain-configuration.v4 semantic configuration state"
    :intent/includes #{:configuration/schema
                       :module-registry/root :verifier-registry/root
                       :evidence-policy/root :escrow-template-registry/root
                       :parameter-policy/root :governance-policy/root
                       :interoperability-policy/root
                       :authority-semantics-policy/root
                       :allocation-entitlement-policy/root
                       :risk-limit-policy/root}
    :intent/excludes #{:runtime-values :functions :deployment-metadata :timestamps}
    :intent/projection-fn project-chain-configuration-v4
    :intent/version 1}

   :prf-chain-configuration-transition-v1
   {:intent/name :prf-chain-configuration-transition-v1
    :intent/domain-tag "PRF_CHAIN_CONFIGURATION_TRANSITION_V1"
    :intent/description "Canonical SHA-256 identity of a chain-configuration-transition.v1 governance transition"
    :intent/includes #{:transition/schema :protocol/genesis-root :target
                       :configuration/parent-root :configuration/new-root
                       :verifier-registry/root :epoch}
    :intent/excludes #{:runtime-values :functions :deployment-metadata
                       :block-context :timestamps}
    :intent/projection-fn project-chain-configuration-transition
    :intent/version 1}

   :prf-verifier-registry-v1
   {:intent/name :prf-verifier-registry-v1
    :intent/domain-tag "PRF_VERIFIER_REGISTRY_V1"
    :intent/description "Canonical SHA-256 commitment to a verifier-registry snapshot:
                            domain-separated hash of sorted verifier entries.
                            Root = SHA256(DOMAIN_TAG || uint256(entry_count) ||
                                   sorted(entry_hashes))"
    :intent/includes #{:verifier/id :verifier/adapter :verifier/program-vkey
                       :verifier/program-elf-sha256 :verifier/program-id
                       :verifier/statement-schema-version-hash
                       :verifier/public-values-schema-hash :verifier/active}
    :intent/excludes #{}
    :intent/projection-fn (fn [v _] v)
    :intent/version 1}

   :extension-registry-v1
   {:intent/name :extension-registry-v1
    :intent/domain-tag "EXTENSION_REGISTRY_V1"
    :intent/description "Canonical SHA-256 commitment to an extension-map verifier
                            registry snapshot: sorted capability entries with their
                            descriptor roots, builtin classification, and provider
                            package identities.
                            Root = SHA256(DOMAIN_TAG || canonical_bytes(sorted_entries))"
    :intent/includes #{:capability-key :descriptor-root :builtin? :providers}
    :intent/excludes #{:runtime-values :functions}
    :intent/projection-fn (fn [v _] v)
    :intent/version 1}

   :prf-resubmission-chain-configuration-v1
   {:intent/name :prf-resubmission-chain-configuration-v1
    :intent/domain-tag "prf.resubmission-chain-configuration.v1"
    :intent/description "Canonical identity of a resubmission-chain-configuration.v1: authority key bindings for a resubmission family"
    :intent/includes #{:configuration/schema :disposition-authority/public-key
                       :receipt-authority/public-key}
    :intent/excludes #{:runtime-values :functions}
    :intent/projection-fn project-resubmission-chain-configuration
    :intent/version 1}

   :prf-resubmission-chain-identity-v1
   {:intent/name :prf-resubmission-chain-identity-v1
    :intent/domain-tag "prf.resubmission-chain-identity.v1"
    :intent/description "Canonical chain-id basis: sha256(family-id + authority keys). Deliberately excludes genesis root so authority rotation preserves chain identity."
    :intent/includes #{:family/id :disposition-authority/public-key
                       :receipt-authority/public-key}
    :intent/excludes #{:runtime-values :functions}
    :intent/projection-fn project-resubmission-chain-identity
    :intent/version 1}

   :prf-resubmission-chain-genesis-v1
   {:intent/name :prf-resubmission-chain-genesis-v1
    :intent/domain-tag "prf.resubmission-chain-genesis.v1"
    :intent/description "Canonical identity of a resubmission-chain-genesis.v1: the declared source of truth for a resubmission chain's family, configuration, and initial state"
    :intent/includes #{:genesis/schema :chain/id :family/id :configuration
                       :initial-state/root}
    :intent/excludes #{:runtime-values :functions :deployment-metadata :timestamps}
    :intent/projection-fn project-resubmission-chain-genesis
    :intent/version 1}

   :prf-resubmission-chain-identity-v2
   {:intent/name :prf-resubmission-chain-identity-v2
    :intent/domain-tag "prf.resubmission-chain-identity.v2"
    :intent/description "Deployment-scoped resubmission chain-id basis: protocol genesis, chain-instance genesis, family, and initial configuration root"
    :intent/includes #{:protocol-genesis/root :chain-instance-genesis/root
                       :family/id :initial-configuration/root}
    :intent/excludes #{:runtime-values :functions}
    :intent/projection-fn project-resubmission-chain-identity-v2
    :intent/version 2}

   :prf-resubmission-chain-genesis-v2
   {:intent/name :prf-resubmission-chain-genesis-v2
    :intent/domain-tag "prf.resubmission-chain-genesis.v2"
    :intent/description "Canonical identity of a deployment-scoped resubmission-chain-genesis.v2"
    :intent/includes #{:genesis/schema :protocol-genesis/root
                       :chain-instance-genesis/root :family/id :chain/id
                       :configuration :configuration/root :initial-state/root}
    :intent/excludes #{:runtime-values :functions :timestamps}
    :intent/projection-fn project-resubmission-chain-genesis-v2
    :intent/version 2}

   :prf-resubmission-chain-genesis-authorization-v1
   {:intent/name :prf-resubmission-chain-genesis-authorization-v1
    :intent/domain-tag "prf.resubmission-chain-genesis-authorization.v1"
    :intent/description "Canonical identity of resubmission-chain-genesis-authorization.v1: thin binding of a genesis root to an authenticated three-member authority decision"
    :intent/includes #{:authorization/schema :authorization/genesis-root
                       :authorization/force-authorisation-hash
                       :authorization/authority-report-root}
    :intent/excludes #{:runtime-values :functions}
    :intent/projection-fn project-resubmission-chain-genesis-authorization
    :intent/version 1}

   :prf-resubmission-authority-context-v1
   {:intent/name :prf-resubmission-authority-context-v1
    :intent/domain-tag "prf.resubmission-authority-context.v1"
    :intent/description "Canonical identity of resubmission-disposition-authority-context.v1: admits a disposition authority key for a chain epoch"
    :intent/includes #{:authority/context-schema :authority/genesis-root
                       :authority/configuration-root :authority/authorization-root
                       :authority/public-key :authority/epoch
                       :authority/permitted-actions}
    :intent/excludes #{:authority/context-root :runtime-values :functions}
    :intent/projection-fn project-resubmission-authority-context
    :intent/version 1}

   :prf-resubmission-authoritative-checkpoint-v1
   {:intent/name :prf-resubmission-authoritative-checkpoint-v1
    :intent/domain-tag "prf.resubmission-authoritative-checkpoint.v1"
    :intent/description "Canonical identity of resubmission-authoritative-checkpoint.v1: binds a chain state-root to an admitted authority context"
    :intent/includes #{:checkpoint/schema :checkpoint/chain-id
                       :checkpoint/genesis-root :checkpoint/state-root
                       :checkpoint/authority-context-root
                       :checkpoint/configuration-root :checkpoint/epoch
                       :checkpoint/authorization-mode :checkpoint/predecessor-root
                       :checkpoint/sequence}
    :intent/excludes #{:checkpoint/root :runtime-values :functions}
    :intent/projection-fn project-resubmission-authoritative-checkpoint
    :intent/version 1}

   :prf-resubmission-authoritative-disposition-v2
   {:intent/name :prf-resubmission-authoritative-disposition-v2
    :intent/domain-tag "prf.resubmission-authoritative-disposition.v2"
    :intent/description "Canonical identity of resubmission-authoritative-disposition.v2: checkpoint-bound disposition signed by the admitted authority key"
    :intent/includes #{:attempt-disposition/schema :attempt-disposition/action
                       :attempt-disposition/chain-id :attempt-disposition/genesis-root
                       :attempt-disposition/configuration-root
                       :attempt-disposition/authority-context-root
                       :attempt-disposition/authority-epoch
                       :attempt-disposition/parent-checkpoint-root
                       :attempt-disposition/sequence
                       :attempt-disposition/attempt-receipt-hash
                       :attempt-disposition/previous-disposition-hash
                       :attempt-disposition/status}
    :intent/excludes #{:attempt-disposition/signature :runtime-values :functions}
    :intent/projection-fn project-resubmission-authoritative-disposition
    :intent/version 2}})

(defn resolve-intent
  "Look up an intent contract by keyword name from the registry.
   Returns the full intent contract map — enriched with the resolved
   :intent/hash-scheme (the immutable canonical-hash-scheme-v1) — or throws
   on unknown intent.
   Used internally by hash-with-intent and available for external
   inspection and linting."
  [intent-kw]
  (or (some-> (hash-intents intent-kw)
              (assoc :intent/hash-scheme canonical-hash-scheme-v1))
      (throw (ex-info "Unknown hash intent"
                      {:intent intent-kw
                       :known (vec (keys hash-intents))}))))

(defn- validate-prefix-free-domain-tags!
  "Fail closed when the domain-tag set violates the consecutive-concatenation
   framing requirement: no tag may be a strict prefix of another.  Because
   domain-hash concatenates DOMAIN_TAG || CANONICAL_BYTES without a length
   frame, a prefix relationship is the only way two distinct (tag, value)
   pairs can collide on the concatenated byte stream.  Returns nil when
   prefix-free, throws ex-info otherwise."
  [tags]
  (doseq [t tags]
    (doseq [t2 tags]
      (when (and (not= t t2)
                 (or (and (< (count t) (count t2)) (.startsWith t2 t))
                     (and (< (count t2) (count t)) (.startsWith t t2))))
        (throw (ex-info "Domain tags must be prefix-free: one domain tag is a strict prefix of another"
                        {:shorter (if (< (count t) (count t2)) t t2)
                         :longer (if (< (count t) (count t2)) t2 t)
                         :guidance "domain-hash concatenates DOMAIN_TAG || CANONICAL_BYTES without a length frame; a prefix relationship makes the boundary ambiguous"}))))))

(defn validate-registry!
  "Validate the intent registry against INTENT_REGISTRY_SPEC_V1.
   Checks that every contract has all required fields with correct types,
   unique domain tags, and projection functions that return canonical-safe data.
   Also validates the canonical-hash-schemes registry: every entry's algorithm
   stays within the declared vocabulary, and the immutable
   canonical-hash-scheme-v1 binding resolves (fail closed at load).
   Returns nil if valid, throws on first violation.
   Call at startup or in test fixtures to ensure registry integrity."
  []
  ;; Explicit scheme pinning: registry entries stay within the declared
  ;; algorithm vocabulary and the v1 binding must resolve — fail closed at load.
  (doseq [[version {:keys [algorithm]}] canonical-hash-schemes]
    (when-not (and (string? version) (seq version))
      (throw (ex-info "Canonical hash scheme version must be a non-empty string"
                      {:type :invalid-hash-scheme :scheme-version version})))
    (hash-algorithm/validate-hash-algorithm! algorithm))
  (validate-hash-scheme! canonical-hash-scheme-v1)
  (let [expected-fields [:intent/name :intent/domain-tag :intent/description
                         :intent/includes :intent/excludes
                         :intent/projection-fn :intent/version]
        field-types {:intent/name keyword?
                     :intent/domain-tag string?
                     :intent/description string?
                     :intent/includes set?
                     :intent/excludes set?
                     :intent/projection-fn fn?
                     :intent/version (every-pred integer? pos?)}]
    (doseq [[kw contract] hash-intents]
      (doseq [f expected-fields]
        (when-not (contains? contract f)
          (throw (ex-info (str "Intent " kw " missing required field " f)
                          {:intent kw :missing f}))))
      (doseq [[f pred] field-types]
        (when-not (pred (get contract f))
          (throw (ex-info (str "Intent " kw " field " f " has wrong type")
                          {:intent kw :field f :value (get contract f)}))))
      (when-not (= kw (:intent/name contract))
        (throw (ex-info "Intent registry key must match :intent/name"
                        {:intent kw :intent/name (:intent/name contract)})))
      (let [validation-samples
            {:action "test-action"
             :action-at {:action-hash "test-hash" :step 1 :block-time 100}
             :with-bounty-effect-set-v1 ["plan-root" ["effect-root-1" "effect-root-2"]]}
            sample (get validation-samples kw {:sample [:a :b] :n 1})
            projection-a ((:intent/projection-fn contract) sample kw)
            projection-b ((:intent/projection-fn contract) sample kw)]
        (try
          (validate-canonical-value! projection-a)
          (catch Exception e
            (throw (ex-info "Intent projection must produce canonical-safe data"
                            {:intent kw
                             :projection projection-a
                             :cause (.getMessage e)}
                            e))))
        (when (not= projection-a projection-b)
          (throw (ex-info "Intent projection must be deterministic"
                          {:intent kw
                           :projection-a projection-a
                           :projection-b projection-b})))
        (when-not ((set (vals domain-tags)) (:intent/domain-tag contract))
          (throw (ex-info "Intent domain tag must be registered in domain-tags"
                          {:intent kw
                           :domain-tag (:intent/domain-tag contract)})))
        ;; Self-hash exclusion cross-check (HASH_INTENT_REGISTRY_SPEC_V1 §2.6):
        ;; every self-hash key declared in :intent/excludes MUST be absent from
        ;; the projection output, so the exclusion is structural, not merely
        ;; declarative — this catches drift even though validate-intent-constraints!
        ;; is off in production.
        (let [excluded-self-hashes (keep #(when (self-hash-keys %) %)
                                         (:intent/excludes contract))]
          (when (seq excluded-self-hashes)
            (let [base (if (map? sample) sample {:sample [:a :b] :n 1})
                  base (if (= kw :action) (assoc base :action/type "test-action") base)
                  self-hash-sample (reduce (fn [m k] (assoc m k "self-hash-sentinel"))
                                           base excluded-self-hashes)
                  projected-self-hash ((:intent/projection-fn contract)
                                       self-hash-sample kw)]
              (doseq [k excluded-self-hashes]
                (when (contains? projected-self-hash k)
                  (throw (ex-info "Intent declares a self-hash exclusion its projection does not implement"
                                  {:intent kw
                                   :self-hash-key k
                                   :guidance "per HASH_INTENT_REGISTRY_SPEC_V1 §2.6 the exclusion must be structural (select-keys / strip-self-hash-fields), not declarative"})))))))))
    (let [tag->intents (reduce-kv (fn [acc kw contract]
                                    (update acc (:intent/domain-tag contract) (fnil conj []) kw))
                                  {}
                                  hash-intents)]
      (doseq [[tag intents] tag->intents]
        (when (< 1 (count intents))
          (throw (ex-info "Intent domain tags must be unique"
                          {:domain-tag tag :intents intents})))))
    ;; Consecutive-concatenation framing requirement (CANONICAL_HASH_SPEC_V1 §2):
    ;; domain-hash is SHA256(DOMAIN_TAG || CANONICAL_BYTES) with no length frame
    ;; on the tag.  For that concatenation to be byte-unambiguous across domains,
    ;; no domain tag may be a strict prefix of another — a prefix relationship is
    ;; the ONLY way two distinct (tag, canonical-bytes) pairs can produce the same
    ;; concatenated stream.  This is enforced here so a future tag cannot silently
    ;; introduce cross-domain collision ambiguity.
    (validate-prefix-free-domain-tags! (set (vals domain-tags)))
    nil))

(validate-registry!)

;; ──────────────────────────────────────────────────────────────────────────────
;; Intent Constraint Enforcement
;; ──────────────────────────────────────────────────────────────────────────────
;; Self-validating identity graph: each intent contract enforces its
;; exclusion rules at test/development time, preventing:
;;   - Accidental misuse (hashing excluded data with wrong intent)
;;   - Silent semantic drift (intent contract drifts from actual usage)
;;   - Cross-intent hash comparison (comparing hashes from different intents)

(def ^:dynamic *validate-intent-constraints*
  "When truthy, hash-with-intent validates data against the intent's
   :intent/excludes before hashing. Enable in tests or development.
   Default false for production performance.

   Usage:
     (binding [hc/*validate-intent-constraints* true]
       (hc/hash-with-intent {:hash/intent :evidence-record} data))"
  false)

(defn- walk-for-excludes
  "Walk a value tree and return all nodes that match any of the given
   type-based exclude predicates. Each predicate takes a value and
   returns a violation string or nil."
  [predicates value]
  (let [results (volatile! [])
        preds (vec predicates)]
    (letfn [(walk [x]
              (doseq [[i pred] (map-indexed vector preds)
                      :let [r (pred x)]
                      :when r]
                (vswap! results conj {:predicate-index i :detail r}))
              (cond
                (instance? clojure.lang.IPersistentMap x)
                (run! (fn [[_ v]] (walk v)) x)
                (instance? clojure.lang.IPersistentVector x)
                (run! walk x)
                (instance? clojure.lang.IPersistentSet x)
                (run! walk x)
                (sequential? x)
                (run! walk x)))]
      (walk value)
      @results)))

(def ^:private exclude-type-checkers
  "Map from exclude category keywords to type-checker predicates.
   Each predicate returns a violation string or nil.
   Applied to every node in the data tree."
  {:functions (fn [v] (when (fn? v) "function value"))
   :sets (fn [v] (when (instance? clojure.lang.IPersistentSet v)
                   "set (unsupported)"))
   :ratios (fn [v] (when (instance? clojure.lang.Ratio v)
                     "ratio (unsupported)"))
   :instants (fn [v] (when (instance? java.time.Instant v)
                       "java.time.Instant"))
   :doubles (fn [v] (when (or (instance? Double v)
                              (instance? Float v))
                      "double or float (unsupported)"))
   :keywords (fn [v] (when (instance? clojure.lang.Keyword v)
                       "keyword value (projected away by :evidence-content)"))})

(def ^:private exclude-root-checkers
  "Map from exclude category keywords to root-level checkers.
   Each predicate takes the ROOT value and returns a violation
   string or nil. These check structural properties."
  {:evidence-hash (fn [v] (when (and (map? v) (contains? v :evidence/hash))
                            "root map contains :evidence/hash"))
   :timestamp (fn [v] (when (and (map? v) (contains? v :evidence/timestamp))
                        "root map contains :evidence/timestamp"))
   :timestamps (fn [v] (when (and (map? v) (contains? v :evidence/timestamp))
                         "root map contains :evidence/timestamp"))
   :hash-fields (fn [v]
                  (when (and (map? v)
                             (some self-hash-keys (keys v)))
                    "map contains a self-hash key at root"))
   :chain-metadata (fn [v]
                     (when (and (map? v)
                                (some #(re-find #"^evidence/chain-" (name %))
                                      (keys v)))
                       "root map contains chain-metadata keys"))})

(defn validate-intent-constraints!
  "Validate that a value does not violate an intent contract's exclusion rules.
   Walks the value tree checking for excluded types and structural patterns.

   Throws ex-info with :violations detailing every detected violation.
   Returns nil if the value passes all checks.

   Runtime/type exclusions use walk-for-excludes (recursive tree walk).
   Structural/root exclusions use exclude-root-checkers (top-level only).
   Unknown exclude categories are silently skipped (they may require
   semantic analysis not expressible as type/structural checks).

   Callers can invoke this directly for defensive checking:
     (hc/validate-intent-constraints! :evidence-record data)"
  [intent-kw value]
  (let [contract (resolve-intent intent-kw)
        excludes (:intent/excludes contract)
        _violations (volatile! [])]
    ;; Tree-walk type checks
    (let [type-preds (keep #(when-let [c (get exclude-type-checkers %)]
                              c)
                           excludes)
          type-violations (walk-for-excludes (vec type-preds) value)
          root-checkers (keep (fn [cat]
                                (when-let [c (get exclude-root-checkers cat)]
                                  [cat c]))
                              excludes)
          root-violations (into []
                                (keep (fn [[cat checker]]
                                        (when-let [msg (checker value)]
                                          {:category cat :detail msg}))
                                      root-checkers))
          all-violations (concat type-violations root-violations)]
      (when (seq all-violations)
        (throw (ex-info "Intent constraint violation"
                        {:intent intent-kw
                         :excludes (vec excludes)
                         :violations (vec all-violations)})))
      nil)))

(defn intent-hash=
  "Compare hash values with intent awareness.
   Prevents accidental cross-intent hash comparison.

   Each argument can be:
   - A map with :hash/intent and :hash/hex keys (intent-aware)
   - A string (legacy plain hex hash, intent-agnostic)

   When both arguments have intent metadata and intents differ,
   returns false. Use :allow-cross-intent? true to override.

   Usage:
     (intent-hash= result1 result2)
     (intent-hash= result1 result2 {:allow-cross-intent? true})"
  ([a b] (intent-hash= a b nil))
  ([a b {:keys [allow-cross-intent?] :or {allow-cross-intent? false}}]
   (let [a-intent (when (map? a) (:hash/intent a))
         b-intent (when (map? b) (:hash/intent b))
         a-hex (if (map? a) (:hash/hex a) a)
         b-hex (if (map? b) (:hash/hex b) b)]
     (if (and a-intent b-intent (not= a-intent b-intent) (not allow-cross-intent?))
       false
       (= a-hex b-hex)))))

(defn hash-with-intent
  "Compute a hash with an explicit intent declaration.

   The intent map documents WHY this hash is being computed, what
   projection (if any) is applied to the data, and what domain tag
   separates the hash. This prevents accidental misuse, silent
   semantic drift, and confusion during refactors.

   When *validate-intent-constraints* is true, validates data against
   the intent's :intent/excludes before hashing (enable in tests).

   Usage:
     (hash-with-intent {:hash/intent :world-structure} world-state)
     (hash-with-intent {:hash/intent :evidence-record} evidence-data)
     (hash-with-intent {:hash/intent :evidence-content} evidence-map)
     (hash-with-intent {:hash/intent :manifest} manifest-data)

   Returns a hex string (64 chars). For intent-aware comparison,
   use intent-hash= or wrap the result:
     {:hash/intent :evidence-record, :hash/hex (hash-with-intent ...)}

   See hash-intents for all supported intents with their scope
   and exclusion contracts."
  [{:keys [hash/intent]} value]
  (let [{:intent/keys [projection-fn domain-tag hash-scheme]} (resolve-intent intent)
        flattened-fields (atom [])
        projected (if (or (= projection-fn project-world-to-structure-view)
                          (= projection-fn project-for-content-hash))
                    (projection-fn value intent flattened-fields)
                    (projection-fn value intent))]
    (when *validate-intent-constraints*
      (validate-intent-constraints! intent value))
    ;; The resolved scheme drives the digest actually executed — the declared
    ;; algorithm is the algorithm used, not metadata beside a hard-coded one.
    (domain-hash-with-scheme hash-scheme
                             domain-tag
                             (if (= projection-fn project-world-to-structure-view)
                               (dissoc projected :projection/flattened-fields)
                               projected))))
