(ns resolver-sim.execution.realization
  "Private runtime realization state shared by claimant execution helpers.

   This namespace intentionally has no dependency on canonical artifacts or
   allocation code so worker dispatch can report facts without a dependency
   cycle."
  (:require [resolver-sim.execution.finalization-lane :as lane]))

(def ^:dynamic *claimant-execution-observation-sink* nil)
(def ^:dynamic *claimant-execution-runtime-profile-root* nil)
(def ^:dynamic *claimant-execution-realization* nil)
(def ^:dynamic *claimant-execution-lane* nil)

(defn- update-while-open!
  [realization f]
  (loop []
    (let [state @realization]
      (when (= :open (:lifecycle state))
        (let [next-state (f state)]
          (if (compare-and-set! realization state next-state)
            true
            (recur)))))))

(defn record! [fact]
  (when-let [realization *claimant-execution-realization*]
    (update-while-open! realization #(update % :phases conj fact))))

(defn open []
  (atom {:lifecycle :open
         :phases []
         :executor-backed-phases 0
         :successfully-quiesced-phases 0
         :emitted? false}))

(defn record-executor-dispatch! [parallelism]
  ;; Admit to the lane first. A rejected late dispatch must not leave the
  ;; realization claiming a phase the lane never accepted.
  (when-let [l *claimant-execution-lane*]
    (lane/record-executor-dispatch! l))
  (when-let [realization *claimant-execution-realization*]
    (update-while-open! realization
                        #(-> %
                             (update :phases conj {:executor-parallelism parallelism})
                             (update :executor-backed-phases inc)))))

(defn record-quiesced! []
  (when-let [l *claimant-execution-lane*]
    (lane/record-quiesced! l))
  (when-let [realization *claimant-execution-realization*]
    (update-while-open! realization #(update % :successfully-quiesced-phases inc))))

(defn- effective [state]
  (let [phases (:phases state)
        executor-parallelism (keep :executor-parallelism phases)
        max-parallelism (apply max 1 executor-parallelism)
        parallel? (> max-parallelism 1)
        budget-limited? (boolean (some :budget-limited? phases))
        reasons (set (keep :reason phases))]
    {:execution/path (if parallel? :parallel :serial)
     :execution/max-claimant-parallelism max-parallelism
     :execution/parallel-work-observed? parallel?
     :execution/budget-limited? budget-limited?
     :execution/reason (cond
                         (and parallel? budget-limited?) :parallel-budget-limited
                         parallel? :parallel
                         budget-limited? :serial-budget-limited
                         (contains? reasons :observer-requires-serial) :serial-observer
                         (contains? reasons :below-claimant-threshold) :serial-threshold
                         :else :serial-requested)}))

(defn freeze!
  "Close a realization to new facts. Freezing is separate from finalization so
   executor quiescence can be checked against an immutable phase record."
  [realization]
  (loop []
    (let [state @realization]
      (when-not (= :open (:lifecycle state))
        (throw (ex-info "Claimant realization is not open"
                        {:lifecycle (:lifecycle state)})))
      (let [frozen (assoc state :lifecycle :frozen)]
        (if (compare-and-set! realization state frozen)
          frozen
          (recur))))))

(defn finalize!
  "Build and retain the optional observation for a frozen realization.
   Finalization never invokes the configured sink."
  [realization]
  (loop []
    (let [state @realization]
      (when-not (= :frozen (:lifecycle state))
        (throw (ex-info "Claimant realization must be frozen before finalization"
                        {:lifecycle (:lifecycle state)})))
      (when-not (= (:executor-backed-phases state)
                   (:successfully-quiesced-phases state))
        (throw (ex-info "Cannot finalize claimant observation before executor quiescence"
                        (select-keys state [:executor-backed-phases
                                            :successfully-quiesced-phases]))))
      (let [observation (when *claimant-execution-runtime-profile-root*
                          (let [build (requiring-resolve 'resolver-sim.execution.observation/build)
                                valid? (requiring-resolve 'resolver-sim.execution.observation/valid?)
                                observation (build {:runtime-profile-root *claimant-execution-runtime-profile-root*
                                                    :effective (effective state)
                                                    :completion {:status :completed}})]
                            (when-not (valid? observation)
                              (throw (ex-info "Execution observation failed validation"
                                              {:observation observation})))
                            observation))
            finalized (assoc state :lifecycle :finalized :observation observation)]
        (if (compare-and-set! realization state finalized)
          observation
          (recur))))))

(defn emit!
  "Emit a finalized observation at most once. Closed root or sink modes are
   intentional no-ops: a missing root produces no observation and a missing sink
   retains the finalized observation without delivery."
  [realization]
  (loop []
    (let [state @realization]
      (when-not (= :finalized (:lifecycle state))
        (throw (ex-info "Claimant realization must be finalized before emission"
                        {:lifecycle (:lifecycle state)})))
      (cond
        (:emitted? state) nil
        (nil? (:observation state)) nil
        (nil? *claimant-execution-observation-sink*) nil
        :else (let [claimed (assoc state :emitted? true)]
                (if (compare-and-set! realization state claimed)
                  (*claimant-execution-observation-sink* (:observation state))
                  (recur)))))))

(defn complete!
  "Complete a successful realization in lifecycle order and deliver its optional
   observation exactly once.

   When `*claimant-execution-lane*` is bound, the lane guards the finalization:
     1. freeze the realization (seal phase record)
     2. close-execution! on the lane (FG-2: proves contributors=0, quiesced)
     3. finalize-lane! acquires the single finalizer ticket (FG-3)
     4. finalize the realization inside the elected write function
     5. emit the observation after the lane commits

   A rejected or aborted lane leaves the realization frozen, not finalized.
   Without a lane, falls back to the original finalize! path."
  [realization]
  (freeze! realization)
  (if-let [l *claimant-execution-lane*]
    (let [{:keys [closed?]} (lane/close-execution! l)]
      (when-not closed?
        (throw (ex-info "Finalization lane closure failed"
                        {:lifecycle (lane/state l)})))
      (let [result (lane/finalize-lane!
                    l
                    {:closed-result-set-root nil
                     :basis-root nil}
                    (fn [_ticket]
                      (let [observation (finalize! realization)]
                        {:committed (or observation {:status :completed})})))]
        (when-not (= :committed (:status result))
          (throw (ex-info "Finalization lane rejected completion"
                          (select-keys result [:status :reason :error]))))
        (emit! realization)
        (:observation @realization)))
    (let [observation (finalize! realization)]
      (emit! realization)
      observation)))

(defn complete-after-authority!
  "Complete a realization through one already-open finalization lane whose elected
   callback performs the authoritative commit.

   The authoritative callback runs before any local realization finalization or
   observation delivery. It must return the durable authority outcome map, whose
   :status is :committed, :idempotent, or a rejection status. An idempotent
   outcome is terminal for the lane but deliberately suppresses local projection
   and emission: this process did not author a new durable successor.

   A failure after durable commitment is reported as a recoverable local
   projection/delivery failure. It never changes the committed lane outcome."
  [realization {:keys [lane observed-parent-root closed-result-set-root basis-root
                       valid-basis? commit!]}]
  (when-not (and lane (fn? commit!))
    (throw (ex-info "Authoritative completion requires a lane and commit callback"
                    {:lane? (boolean lane) :commit-callback? (fn? commit!)})))
  (freeze! realization)
  (let [{:keys [closed?]} (lane/close-execution! lane)]
    (when-not closed?
      (throw (ex-info "Finalization lane closure failed"
                      {:lifecycle (lane/state lane)})))
    (let [lane-result
          (lane/finalize-lane!
           lane
           (cond-> {:closed-result-set-root closed-result-set-root
                    :basis-root basis-root}
             (some? observed-parent-root)
             (assoc :observed-parent-root observed-parent-root)
             (contains? #{true false} valid-basis?)
             (assoc :valid-basis? valid-basis?))
           (fn [ticket]
             (let [authority (commit! ticket)]
               (case (:status authority)
                 (:committed :idempotent) {:committed authority}
                 {:rejected (:reason authority)}))))]
      (when-not (= :committed (:status lane-result))
        (throw (ex-info "Authoritative finalization lane rejected completion"
                        (select-keys lane-result [:status :reason :error]))))
      (let [authority (:result lane-result)]
        (case (:status authority)
          :idempotent
          {:status :suppressed
           :reason :already-authoritatively-published
           :authority authority
           :ticket (:ticket lane-result)}

          :committed
          (try
            (let [observation (finalize! realization)]
              (emit! realization)
              {:status :committed
               :authority authority
               :ticket (:ticket lane-result)
               :observation observation})
            (catch Exception error
              (throw (ex-info "Authority committed but local realization projection failed"
                              {:status :authoritative-committed-local-projection-failed
                               :authority authority
                               :ticket (:ticket lane-result)
                               :local-lifecycle (:lifecycle @realization)}
                              error))))

          (throw (ex-info "Authoritative callback returned unsupported committed outcome"
                          {:authority authority})))))))
